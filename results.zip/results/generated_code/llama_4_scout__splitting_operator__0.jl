function strang_splitting(u0, dt, nt, L1, L2)
    u = copy(u0)
    half_dt = dt / 2
    for _ in 1:nt
        u = L1(half_dt, u)
        u = L2(dt, u)
        u = L1(half_dt, u)
    end
    return u
end