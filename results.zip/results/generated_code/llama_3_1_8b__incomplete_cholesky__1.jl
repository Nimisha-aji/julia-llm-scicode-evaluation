function incomplete_cholesky(A, drop_tol=1e-4, fillin=0)
    n = size(A, 1)
    L = zeros(n, n)
    Ldiag = zeros(n)
    Lfill = zeros(n)
    Lfill[1] = 1

    for k = 1:n
        if k <= fillin
            L[k, 1:k] .= 1
        else
            for i = k-1:-1:1
                L[i, k] = (A[i, k] - sum(L[i, 1:k-1] .* L[k, 1:k-1])) / Ldiag[k-1]
            end
        end

        Ldiag[k] = A[k, k] - sum(L[k, 1:k-1] .^ 2)
        if Ldiag[k] < 0
            error("Matrix is not positive definite")
        end
        Ldiag[k] = sqrt(Ldiag[k])

        if k < n
            for i = k+1:n
                L[i, k] = (A[i, k] - sum(L[i, 1:k-1] .* L[k, 1:k-1])) / Ldiag[k]
                if abs(L[i, k]) < drop_tol * Ldiag[k]
                    L[i, k] = 0
                end
            end
        end
    end

    return L
end