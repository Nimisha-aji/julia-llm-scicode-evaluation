function gram_schmidt(A)
    m, n = size(A)
    Q = similar(A, m, n)
    for j = 1:n
        v = A[:, j]
        for i = 1:j-1
            q = Q[:, i]
            v = v - dot(q, v) * q
        end
        norm_v = norm(v)
        if norm_v < 1e-10
            error("Gram-Schmidt: linear dependency")
        end
        Q[:, j] = v / norm_v
    end
    return Q
end