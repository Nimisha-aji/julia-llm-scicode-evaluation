using Random
using Statistics
using LinearAlgebra
using IterativeSolvers
using Plots

function ica_demix(X::Matrix{<:Number}, n_components::Int64, max_iter::Int64, tol::Float64)
    Random.seed!(42)

    # Check if X is square and has real entries
    if size(X, 1) != size(X, 2) || any(x -> iscomplex(x), eltype.(X))
        error("Input matrix X must be square and have real entries.")
    end

    # Calculate mean of X
    μ = mean(X, dims=1)

    # Subtract mean from X
    X_mean_subtracted = X .- μ

    # Calculate covariance matrix of X_mean_subtracted
    C = cov(X_mean_subtracted)

    # Normalize columns of C
    C_norm = C ./ sqrt.(diag(C))

    # Calculate mixing matrix W
    W = solve(C_norm, X_mean_subtracted)

    # Calculate independent components
    components = vec(W' * X_mean_subtracted)

    # Perform FastICA algorithm
    for _ in 1:max_iter
        # Calculate mixing matrix W_new
        W_new = solve(C_norm, components)

        # Calculate independent components
        components = vec(W_new' * X_mean_subtracted)

        # Check convergence
        if norm(W - W_new) < tol
            break
        end
    end

    # Return demixing matrix W
    return W
end