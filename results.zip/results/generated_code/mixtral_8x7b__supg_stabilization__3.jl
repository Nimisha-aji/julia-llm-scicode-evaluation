function s upg_tau(u, kappa, h)
    return (1.0 / (h * kappa)) * sqrt(abs(u))
end