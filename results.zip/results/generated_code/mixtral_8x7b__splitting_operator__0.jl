function strang_splitting(u0::Array{T,1}, dt::T, nt::T, L1::Function, L2::Function) where T<:Real
    u = zeros(nt+1, length(u0))
    for i in 1:nt
        u[i+1,:] = L1(u0, dt) + L2(u0, dt) * (1.0 / nt)
    end