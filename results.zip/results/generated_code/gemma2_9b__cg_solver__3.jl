function cg_solver(A, b, x0, tol)
    x = copy(x0)
    r = b - A * x
    p = copy(r)
    rsold = dot(r, r)
    for i in 1:length(b)
        Ap = A * p
        alpha = rsold / dot(p, Ap)
        x .= x .+ alpha .* p
        r .= r .- alpha .* Ap
        rsnew = dot(r, r)
        if sqrt(rsnew) < tol
            break
        end
        beta = rsnew / rsold
        p = r .+ beta .* p
        rsold = rsnew
    end
    return x
end