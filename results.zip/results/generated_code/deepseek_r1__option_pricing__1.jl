using Random, Statistics

function black_scholes_mc(S0::Float64, K::Float64, r::Float64, sigma::Float64,
                          T::Float64, n_paths::Int, n_steps::Int)::Float64
    Random.seed!(42)
    dt = T / n_steps
    drift = (r - 0.5 * sigma^2) * dt
    diffusion = sigma * sqrt(dt)

    payoffs = zeros(Float64, n_paths)
    for i in 1:n_paths
        S = S0
        for _ in 1:n_steps
            Z = randn()
            S *= exp(drift + diffusion * Z)
        end
        payoffs[i] = max(S - K, 0.0)
    end
    discounted_price = exp(-r * T) * mean(payoffs)
    return Float64(discounted_price)
end