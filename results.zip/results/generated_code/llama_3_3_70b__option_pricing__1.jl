using Random

function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    paths = zeros(n_paths)
    for i in 1:n_paths
        S = S0
        for j in 1:n_steps
            S *= exp((r - 0.5 * sigma^2) * dt + sigma * sqrt(dt) * randn())
        end
        paths[i] = S
    end
    payoff = max.(paths .- K, 0)
    price = exp(-r * T) * mean(payoff)
    return Float64(price)
end