function lanczos(A, v0, k)
    n = length(v0)
    v0_norm = norm(v0)
    if v0_norm ≈ 0
        error("Initial vector must be non-zero")
    end
    v_current = v0 / v0_norm
    v_prev = zeros(n)
    beta_prev = 0.0
    alpha = Vector{Float64}(undef, k)
    beta = Vector{Float64}(undef, k)
    for i in 1:k
        w = A * v_current
        α = dot(v_current, w)
        w -= α * v_current + beta_prev * v_prev
        β = norm(w)
        alpha[i] = α
        beta[i] = β
        v_prev, v_current = v_current, w / β
        beta_prev = β
    end
    return (alpha, beta)
end