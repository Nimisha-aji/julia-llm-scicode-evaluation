function strang_splitting(u0::Array, dt::Real, nt::Int64, L1::Function, L2::Function, L3::Function)
    L3_sum = 0.0
    for i in 1:nt
        u1 = L1(u0)
        u2 = L2(u0)
        u3 = L3(u0)
        u0 = (u1 + dt*(u2 + dt*(u3))) / 2.0
        L3_sum += dt^2 * (u3 - u2)
    end