function gauss_seidel(A, b, x0, tol, max_iter)
    n = size(A, 1) # number of variables
    x = zeros(n) # initial guess for solution vector

    for iter in 1:max_iter
        for i in 1:n
            x[i] = (b[i] - sum([A[j, i] * x[j] for j in 1:n])) / sum([A[i, i]])
        end