using LinearAlgebra, Random, Statistics

function ica_demix(X::AbstractMatrix, n_components::Int, max_iter::Int, tol::Float64)
    Random.seed!(42)
    # Center
    Xc = X .- mean(X, dims=2)
    # Whiten
    covX = cov(Xc; dims=2)
    E, D = eigen(covX)
    Dinv_sqrt = Diagonal(1 ./ sqrt.(D))
    K = Dinv_sqrt * E'
    Xw = K * Xc
    # Initialize W
    W = randn(n_components, n_components)
    # Symmetric decorrelation function
    decorrelate!(W) = begin
        C = W * W'
        E2, D2 = eigen(C)
        W .= (D2 .^ (-0.5)) .* (E2' * W)
    end
    decorrelate!(W)
    N = size(Xw, 2)
    for i in 1:max_iter
        Y = W * Xw
        G = tanh.(Y)
        Gp = 1 .- G.^2
        W_new = (G * Xw') / N .- Diagonal(mean(Gp, dims=2)[:]) * W
        decorrelate!(W_new)
        if norm(abs.(W_new * W') .- I, Inf) < tol
            W = W_new
            break
        end
        W = W_new
    end
    return W
end