function householder_qr(A)
    m, n = size(A)
    Q = eye(m)
    R = copy(A)
    for i = 1:min(m-1, n)
        x = view(R, i:m, i)
        e1 = zeros(m-i+1)
        e1[1] = norm(x)
        v = x - e1
        v ./= norm(v)
        H = eye(m)
        H[i:m, i:m] .= eye(m-i+1) - 2 * v * v'
        Q *= H
        R *= H
    end
    return Q, triu(R)
end