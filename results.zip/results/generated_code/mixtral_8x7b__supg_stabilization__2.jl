function s upg_tau(u, kappa, h)
    return (kappa / (h^2)) * sqrt(abs(u))
end