function gram_schmidt(A)
    Q = copy(A)
    n = size(Q, 2)
    for i in 1:n
        for j in 1:i-1
            Q[:,i] -= dot(Q[:,j], Q[:,i]) * Q[:,j]
        end
        Q[:,i] /= norm(Q[:,i])
    end
    return Q
end