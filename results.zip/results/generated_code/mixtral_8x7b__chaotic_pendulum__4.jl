function pendulum_rk4(theta0, omega0, dt, nt, g, L, b)
    θ = theta0
    ω = omega0
    
    function f(θ, ω)
        return [g * L * sin(θ), -g * L * cos(θ) - b * ω^2 * sin(θ)]
    end