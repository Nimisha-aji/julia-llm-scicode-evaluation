function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    Dinv = 1.0 ./ diag(A)
    x = copy(x0)
    for k in 1:max_iter
        r = b .- A * x
        dx = omega .* (Dinv .* r)
        x .+= dx
        if norm(dx, Inf) < tol
            break
        end
    end
    return x
end