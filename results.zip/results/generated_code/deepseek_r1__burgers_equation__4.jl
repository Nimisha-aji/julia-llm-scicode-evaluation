function burgers_solver(nu::Float64, nx::Int, nt::Int, dx::Float64, dt::Float64)
    # spatial grid
    x = range(0, step=dx, length=nx)
    # initial condition (periodic)
    u = @. sin(2π * x)
    # allocate temporary array
    u_new = similar(u)

    for _ = 1:nt
        @inbounds for i = 1:nx
            # periodic indices
            ip = i == nx ? 1 : i + 1
            im = i == 1  ? nx : i - 1

            # upwind convection term
            if u[i] ≥ 0
                du_dx = (u[i] - u[im]) / dx
            else
                du_dx = (u[ip] - u[i]) / dx
            end

            # central diffusion term
            d2u_dx2 = (u[ip] - 2u[i] + u[im]) / dx^2

            # explicit update
            u_new[i] = u[i] - dt * u[i] * du_dx + dt * nu * d2u_dx2
        end
        # swap references
        u, u_new = u_new, u
    end
    return u
end