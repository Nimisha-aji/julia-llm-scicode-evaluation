function s upg_tau(u, kappa, h)
    tau = (1 + kappa*h) / (1 + kappa^2*h^2)
    return Float64(tau)
end