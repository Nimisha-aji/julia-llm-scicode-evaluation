function burgers_solver(nu, nx, nt, dx, dt)
    u = zeros(nx)

    for t in 1:nt
        u_new = (1.0 / dx) * (u[1] + 2.0 * u[2:end