function s upg_tau(u, kappa, h)
    return (1.0 / (h^2 * kappa)) * (1.0 + sqrt(1.0 + 8.0 * h^2 / (kappa * (u^2 + kappa))) - 1.0)
end