function lanczos(A::AbstractMatrix, v0::AbstractVector, k::Int)
    n = length(v0)
    v = copy(v0) / norm(v0)
    v_prev = zeros(eltype(A), n)
    α = Vector{eltype(A)}(undef, k)
    β = Vector{eltype(A)}(undef, k-1)

    for j in 1:k
        w = A * v - (j > 1 ? β[j-1] * v_prev : zero(v))
        α[j] = dot(v, w)
        w .-= α[j] * v
        if j < k
            β[j] = norm(w)
            if β[j] == 0
                # Truncate arrays if Lanczos terminates early
                α = α[1:j]
                β = β[1:j-1]
                break
            end
            v_prev .= v
            v .= w / β[j]
        end
    end
    return (α, β)
end