function gram_schmidt(A)
    n, m = size(A)
    Q = zeros(n, m)
    for j in 1:m
        v = A[:, j]
        for i in 1:j-1
            v -= (Q[:, i]' * A[:, j]) * Q[:, i]
        end
        Q[:, j] = v / norm(v)
    end
    return Q
end