using FastICA

function ica_demix(X, n_components, max_iter, tol)
    Random.seed!(42)
    ica = FastICA.FastICA(n_components=n_components, max_iter=max_iter, tol=tol)
    ica.fit(X)
    W = ica.components_
    return W
end