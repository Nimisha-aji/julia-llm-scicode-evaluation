function lanczos(A, v0, k)
    n = size(A, 1)
    v = copy(v0)
    norm_v = norm(v)
    if norm_v == 0
        error("Initial vector is zero")
    end
    q = v / norm_v
    alphas = Vector{Float64}(undef, k)
    betas = Vector{Float64}(undef, k-1)
    prev_q = q
    curr_q = q
    for i in 1:k
        # Compute A * curr_q
        w = A * curr_q
        alpha_i = dot(curr_q, w)
        alphas[i] = alpha_i
        # Compute w = A curr_q - alpha_i curr_q - beta_{i-1} prev_q
        # Wait, beta_{i-1} is from previous step
        # For the first iteration, beta_{i-1} is zero?
        if i > 1
            w -= betas[i-2] * prev_q  # because for i=1, betas is not yet filled
        end
        w -= alpha_i * curr_q
        beta_i = norm(w)
        betas[i-1] = beta_i
        # Now, next iteration's prev_q is curr_q, and next curr_q is w / beta_i
        prev_q = curr_q
        curr_q = w / beta_i
    end
    return (alphas, betas)
end