function supg_tau(u, kappa, h)
    return (u*h)/kappa
end