function incomplete_cholesky(A)
    n = size(A, 1)
    L = zeros(n, n)

    for i in 1:n
        for j in (1:n) .< i
            L[i, j] = sqrt(A[i, j] / A[j, j])
        end