using LinearAlgebra

function cg_solver(A, b, x0, tol)
    x = copy(x0)
    r = b - A * x
    r_norm = norm(r)
    if r_norm ≤ tol
        return x
    end
    p = r
    while true
        Ap = A * p
        α = r_norm^2 / dot(p, Ap)
        x .= x .+ α .* p
        r_new = r - α * Ap
        r_new_norm = norm(r_new)
        if r_new_norm ≤ tol
            return x
        end
        β = r_new_norm^2 / r_norm^2
        p = r_new + β * p
        r = r_new
        r_norm = r_new_norm
    end
end