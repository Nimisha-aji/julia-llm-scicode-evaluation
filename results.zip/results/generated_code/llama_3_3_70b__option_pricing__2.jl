using Random

function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    paths = zeros(n_paths)
    for i in 1:n_paths
        S = S0
        for j in 1:n_steps
            S *= exp((r - 0.5 * sigma^2) * dt + sigma * sqrt(dt) * randn())
        end
        paths[i] = max(S - K, 0)
    end
    return exp(-r * T) * mean(paths)
end

# Example usage
S0 = 100.0
K = 100.0
r = 0.05
sigma = 0.2
T = 1.0
n_paths = 100000
n_steps = 100
price = black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
println(price)