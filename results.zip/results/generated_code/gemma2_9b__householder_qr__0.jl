function householder_qr(A)
    m, n = size(A)
    R = copy(A)
    Q = Matrix{Float64}(I, m, m)

    for j in 1:n
        x = view(R, j:m, j)
        σ = norm(x)
        if σ == 0
            v = copy(x)
        else
            v = x / (x[1] + sign(x[1]) * σ)
            v[1] += 1.0
        end
        v = v / norm(v)
        R[j:m, j:n] .-= 2 * v * (v' * R[j:m, j:n])
        Q[:, j:m] .-= 2 * (Q[:, j:m] * v) * v'
    end

    return Q, R
end