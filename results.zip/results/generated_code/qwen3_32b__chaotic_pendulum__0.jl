function f(state, t, g, L, b)
    θ, ω = state
    dθdt = ω
    dωdt = -b * ω - (g/L) * sin(θ)
    return [dθdt, dωdt]
end