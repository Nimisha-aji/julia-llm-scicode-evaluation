function lanczos(A::Matrix{<:Number}, v0::Vector{<:Number}, k::Integer)
    α, β = zero(eltype(A)), zero(eltype(A))
    v = v0

    for i in 1:k
        α, β = lanczos_step(A, α, β, v)
        v = normalize(v')
    end