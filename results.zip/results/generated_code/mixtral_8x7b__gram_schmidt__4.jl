function gram_schmidt(A::Matrix{<:Real})
    n, m = size(A)
    Q = zeros(m, m)

    for i in 1:m
        v = A[:, i]
        Q[:, i] = v / norm(v)

        for j in (i+1):m
            u = Q[:, j]
            Q[:, j] = u - dot(v, u) * Q[:, i]
        end