using Random

function black_scholes_mc(S0::Float64, K::Float64, r::Float64, sigma::Float64, T::Float64, n_paths::Int64, n_steps::Int64)
    Random.seed!(42)

    # Calculate the strike price
    strike = K * sqrt(T)

    # Calculate the call price using Monte Carlo
    call_price = mean([max(0.0, S0 + (1.0 + r*(1.0 - c)^n_steps) * sqrt(T) * randn() * sqrt(T) - strike) for c in 0:n_steps])

    return call_price
end