function householder_qr(A)
    m, n = size(A)
    Q = I(m)
    R = copy(A)
    for j = n-1:-1:1
        v = R[j:n, j]
        v = v ./ norm(v)
        h = I(n-j+1) - 2 * v * v'
        R[j:n, j:n] = h * R[j:n, j:n]
        Q = Q * h
    end
    return Q, R
end