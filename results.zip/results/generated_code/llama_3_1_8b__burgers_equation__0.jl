function burgers_solver(nu, nx, nt, dx, dt)
    u = zeros(nx)
    u[:] = 1.0
    u[1] = 0.5
    u[nx] = 1.5
    u_new = zeros(nx)
    for it in 1:nt
        for i in 2:nx
            if u[i-1] >= u[i]
                u_new[i] = u[i] - nu * dt / dx * (u[i] - u[i-1])
            else
                u_new[i] = u[i] + nu * dt / dx * (u[i+1] - u[i])
            end
        end
        u_new[1] = 0.5
        u_new[nx] = 1.5
        for i in 2:nx-1
            u_new[i] = u_new[i]
        end
        u[:] = u_new[:]
    end
    return u
end