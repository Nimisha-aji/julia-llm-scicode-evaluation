function lanczos(A, v0, k)
    n = length(v0)
    q = v0 / norm(v0)
    q_prev = zeros(eltype(v0), n)
    α = zeros(eltype(v0), k)
    β = zeros(eltype(v0), max(k-1, 0))
    for i in 1:k
        w = A * q
        if i > 1
            w .-= β[i-1] .* q_prev
        end
        α[i] = dot(q, w)
        w .-= α[i] .* q
        if i < k
            β[i] = norm(w)
            if β[i] == 0
                # Lanczos terminates early
                α = α[1:i]
                β = β[1:i-1]
                break
            end
            q_next = w / β[i]
            q_prev .= q
            q .= q_next
        end
    end
    return (α, β)
end