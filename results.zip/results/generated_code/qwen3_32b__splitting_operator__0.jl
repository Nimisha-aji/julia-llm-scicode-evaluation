function strang_splitting(u0, dt, nt, L1, L2)
    u = copy(u0)
    for _ in 1:nt
        u = L1(u, dt/2)
        u = L2(u, dt)
        u = L1(u, dt/2)
    end
    return u
end