function lanczos(A, v0, k)
    alpha = zeros(k)
    beta = zeros(k)
    v = copy(v0)
    v = v ./ norm(v)
    alpha[1] = dot(v, A * v)
    for i in 2:k
        w = A * v - alpha[i-1] * v
        beta[i-1] = norm(w)
        if beta[i-1] == 0
            return alpha[1:i-1], beta[1:i-1]
        end
        w = w ./ beta[i-1]
        alpha[i] = dot(w, A * w)
        v = w
    end
    return alpha, beta
end