function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    Δt = T / n_steps
    Z = randn(n_steps, n_paths)
    S_T = S0 * exp((r - 0.5*sigma^2)*T .+ sigma*sqrt(Δt)*sum(Z, dims=1))
    payoffs = max.(S_T .- K, 0)
    price = mean(payoffs) * exp(-r*T)
    return price
end