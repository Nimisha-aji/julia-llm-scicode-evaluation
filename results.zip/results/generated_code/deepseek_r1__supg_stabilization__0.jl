function supg_tau(u::Real, kappa::Real, h::Real)::Float64
    u_abs = abs(float(u))
    kappa = float(kappa)
    h = float(h)
    if u_abs == 0.0
        return h^2 / (12.0 * kappa)
    else
        Pe = u_abs * h / (2.0 * kappa)
        return (h / (2.0 * u_abs)) * (coth(Pe) - 1.0 / Pe)
    end
end