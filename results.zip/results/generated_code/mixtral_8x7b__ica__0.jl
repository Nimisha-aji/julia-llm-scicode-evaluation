using Random
using LinearAlgebra
using Statistics
using IterativeSolvers

function ica_demix(X::Matrix{<:Number}, n_components::Int64, max_iter::Int64, tol::Float64)
    Random.seed!(42)

    # Check input dimensions
    if size(X, 1) != size(X, 2)
        error("Input matrix X must have the same number of rows and columns.")
    end

    # Calculate mean of X
    mean_X = mean(X, dims=1)

    # Subtract mean from X
    X_mean_subtracted = X .- mean_X

    # Calculate covariance matrix of X_mean_subtracted
    cov_X = cov(X_mean_subtracted)

    # Calculate eigenvalues and eigenvectors of covariance matrix
    eigenvalues, eigenvectors = eig(cov_X)

    # Sort eigenvalues in descending order
    sorted_eigenvalues = sortperm(eigenvalues)[1:end-n_components:end]

    # Select n_components largest eigenvalues and corresponding eigenvectors
    sorted_eigenvectors = eigenvectors[:, sorted_eigenvalues]

    # Calculate demixing matrix W
    W = sorted_eigenvectors[:, 1:n_components]

    # Normalize W
    W = W / norm(W, Infinity)

    # Perform FastICA algorithm
    for _ in 1:max_iter
        # Calculate mixing matrix A
        A = X_mean_subtracted .* W

        # Calculate independent components
        independent_components = A .* A'

        # Calculate demixing matrix W_new
        W_new = independent_components .* W

        # Update W
        W = W_new

        # Check convergence
        if norm(W_new - W, Infinity) < tol
            break
        end
    end

    return W
end