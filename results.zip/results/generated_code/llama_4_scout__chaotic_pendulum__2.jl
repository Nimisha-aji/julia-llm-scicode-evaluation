function pendulum_rk4(theta0, omega0, dt, nt, g, L, b)
    theta = zeros(nt+1)
    omega = zeros(nt+1)
    theta[1] = theta0
    omega[1] = omega0

    for i in 1:nt
        dtheta_dt = omega[i]
        domega_dt = -(g/L)*sin(theta[i]) - b*omega[i]

        k1_theta = dt*dtheta_dt
        k1_omega = dt*domega_dt

        dtheta_dt = omega[i] + 0.5*k1_omega
        domega_dt = -(g/L)*sin(theta[i] + 0.5*k1_theta) - b*(omega[i] + 0.5*k1_omega)

        k2_theta = dt*dtheta_dt
        k2_omega = dt*domega_dt

        dtheta_dt = omega[i] + 0.5*k2_omega
        domega_dt = -(g/L)*sin(theta[i] + 0.5*k2_theta) - b*(omega[i] + 0.5*k2_omega)

        k3_theta = dt*dtheta_dt
        k3_omega = dt*domega_dt

        dtheta_dt = omega[i] + k3_omega
        domega_dt = -(g/L)*sin(theta[i] + k3_theta) - b*(omega[i] + k3_omega)

        k4_theta = dt*dtheta_dt
        k4_omega = dt*domega_dt

        theta[i+1] = theta[i] + (1/6)*(k1_theta + 2*k2_theta + 2*k3_theta + k4_theta)
        omega[i+1] = omega[i] + (1/6)*(k1_omega + 2*k2_omega + 2*k3_omega + k4_omega)
    end

    return theta
end