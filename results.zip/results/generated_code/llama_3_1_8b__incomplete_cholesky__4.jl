function incomplete_cholesky(A, k=1)
    n = size(A, 1)
    L = zeros(n, n)
    D = zeros(n)
    for i in 1:n
        L[i, i] = sqrt(A[i, i])
        D[i] = A[i, i]
        for j in (i+1):min(i+k, n)
            L[i, j] = A[i, j] / L[i, i]
            for p in 1:(i-1)
                A[i, j] -= L[i, p] * L[p, j]
            end
        end
    end
    return L
end