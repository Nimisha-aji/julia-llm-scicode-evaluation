function cg_solver(A, b, x0, tol)
    n = length(b)
    x = copy(x0)
    r = b - A * x
    p = copy(r)
    rsold = dot(r, r)
    iter = 0
    max_iter = n

    while iter < max_iter && sqrt(rsold) > tol
        Ap = A * p
        alpha = rsold / dot(p, Ap)
        x += alpha * p
        r -= alpha * Ap
        rsnew = dot(r, r)
        p = r + (rsnew / rsold) * p
        rsold = rsnew
        iter += 1
    end

    return x
end