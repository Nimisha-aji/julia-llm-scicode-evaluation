function gauss_seidel(A, b, x0, tol, max_iter)
    n = size(A, 1)
    x = copy(x0)
    for i in 1:max_iter
        x_new = copy(x)
        for j in 1:n
            s = 0
            for k in 1:j-1
                s += A[j, k] * x_new[k]
            end
            for k in j+1:n
                s += A[j, k] * x[k]
            end
            x_new[j] = (b[j] - s) / A[j, j]
        end
        if norm(x_new - x) < tol
            return x_new
        end
        x = copy(x_new)
    end
    return x
end