function supg_tau(u, kappa, h)
    c = maximum(abs.(u))
    return (c * h / kappa)^2
end