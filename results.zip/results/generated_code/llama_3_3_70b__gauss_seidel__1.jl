function gauss_seidel(A, b, x0, tol, max_iter)
    n = length(b)
    x = copy(x0)
    iter = 0
    while iter < max_iter
        x_new = copy(x)
        for i in 1:n
            s = 0
            for j in 1:n
                if j != i
                    s += A[i, j] * x[j]
                end
            end
            x_new[i] = (b[i] - s) / A[i, i]
        end
        if norm(x_new - x) < tol
            return x_new, iter
        end
        x = x_new
        iter += 1
    end
    return x, iter
end