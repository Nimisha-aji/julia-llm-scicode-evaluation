using LinearAlgebra

function gram_schmidt(A)
    n, m = size(A)
    Q = zeros(n, m)
    for i in 1:m
        v = A[:,i]
        for j in 1:i-1
            v -= dot(v, Q[:,j]) * Q[:,j]
        end
        Q[:,i] = v / norm(v)
    end
    return Q
end