function nurbs_basis(i, p, t, knots)
    if p == 0
        return (knots[i+1] <= t && t < knots[i+2]) ? 1.0 : 0.0
    else
        return (t - knots[i]) / (knots[i+p+1] - knots[i]) * nurbs_basis(i, p-1, t, knots) +
               (knots[i+p+1] - t) / (knots[i+p+2] - knots[i]) * nurbs_basis(i+1, p-1, t, knots)
    end
end