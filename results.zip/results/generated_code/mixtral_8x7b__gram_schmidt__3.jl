function gram_schmidt(A::Matrix{<:Number})
    n, m = size(A)
    Q = zeros(eltype(A), n, m)

    for i in 1:m
        v = A[:, i]
        Q[:, i] = v / norm(v)

        for j in (i+1):m
            u = v - dot(v, Q[:, j]) * Q[:, j]
            Q[:, i] = Q[:, i] + u / norm(u)
        end