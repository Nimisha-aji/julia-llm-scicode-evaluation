function supg_tau(u, kappa, h)
    abs_u = abs(u)
    term = 2 * kappa / (abs_u * h)
    return h / (2 * abs_u) / sqrt(1 + term^2)
end