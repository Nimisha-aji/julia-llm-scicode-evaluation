function nurbs_basis(i::Int, p::Int, t::Float64, knots::Vector{Float64})::Float64
    if p == 0
        return (t >= knots[i] && t < knots[i+1]) ? 1.0 : 0.0
    else
        term1 = 0.0
        term2 = 0.0
        denom1 = knots[i+p] - knots[i]
        denom2 = knots[i+p+1] - knots[i+1]
        if denom1 != 0
            term1 = ((t - knots[i]) / denom1) * nurbs_basis(i, p-1, t, knots)
        end
        if denom2 != 0
            term2 = ((knots[i+p+1] - t) / denom2) * nurbs_basis(i+1, p-1, t, knots)
        end
        return term1 + term2
    end
end