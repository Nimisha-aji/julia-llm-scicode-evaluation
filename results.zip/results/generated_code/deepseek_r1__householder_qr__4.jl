using LinearAlgebra

function householder_qr(A::AbstractMatrix)
    m, n = size(A)
    R = copy(A)
    Q = Matrix{eltype(A)}(I, m, m)

    for k = 1:min(m-1, n)
        # Extract the vector to reflect
        x = R[k:end, k]
        α = norm(x)
        if α == 0
            continue
        end
        # Determine sign to avoid cancellation
        σ = -sign(x[1])
        σ = σ == 0 ? -1 : σ
        v = copy(x)
        v[1] -= σ * α
        v /= norm(v)

        # Apply Householder to R (from the left)
        R[k:end, k:end] .-= 2 .* (v * (v' * R[k:end, k:end]))

        # Apply Householder to Q (from the right, i.e., Q = Q * H')
        Q[:, k:end] .-= 2 .* (Q[:, k:end] * v) * v'
    end

    return Q, R
end