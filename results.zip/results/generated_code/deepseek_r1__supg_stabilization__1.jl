function supg_tau(u::Real, kappa::Real, h::Real)::Float64
    u_abs = abs(float(u))
    kappa = float(kappa)
    h = float(h)
    if u_abs == 0.0
        return h^2 / (12.0 * kappa)
    end
    Pe = u_abs * h / (2.0 * kappa)
    if Pe < 1e-8
        # Use series expansion for small Pe to avoid cancellation
        return h^2 / (12.0 * kappa) * (1.0 - Pe^2/30.0)
    else
        return (h / (2.0 * u_abs)) * (coth(Pe) - 1.0 / Pe)
    end
end