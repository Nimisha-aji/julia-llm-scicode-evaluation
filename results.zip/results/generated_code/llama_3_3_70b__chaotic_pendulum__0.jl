function pendulum_rk4(theta0, omega0, dt, nt, g, L, b)
    theta = zeros(nt+1)
    omega = zeros(nt+1)
    theta[1] = theta0
    omega[1] = omega0

    for n in 1:nt
        k1_theta = omega[n]
        k1_omega = (-b*omega[n] - (g/L)*sin(theta[n]))

        k2_theta = omega[n] + 0.5*dt*k1_omega
        k2_omega = (-b*(omega[n] + 0.5*dt*k1_omega) - (g/L)*sin(theta[n] + 0.5*dt*k1_theta))

        k3_theta = omega[n] + 0.5*dt*k2_omega
        k3_omega = (-b*(omega[n] + 0.5*dt*k2_omega) - (g/L)*sin(theta[n] + 0.5*dt*k2_theta))

        k4_theta = omega[n] + dt*k3_omega
        k4_omega = (-b*(omega[n] + dt*k3_omega) - (g/L)*sin(theta[n] + dt*k3_theta))

        theta[n+1] = theta[n] + (dt/6)*(k1_theta + 2*k2_theta + 2*k3_theta + k4_theta)
        omega[n+1] = omega[n] + (dt/6)*(k1_omega + 2*k2_omega + 2*k3_omega + k4_omega)
    end

    return theta
end