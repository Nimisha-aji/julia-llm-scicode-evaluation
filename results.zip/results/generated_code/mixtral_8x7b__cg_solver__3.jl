function cg_solver(A::Array{T,2}, b::Array{T,1}, x0::Array{T,1}, tol::T) where T<:Number
    n, m = size(A)
    x = x0
    alpha = 1.0
    beta = 0.0
    
    while true
        p = A * x
        q = b - p
        r = q
        
        while true
            s = r * r' / (p * p' + alpha * beta * r * r')
            r -= alpha * s * p
            p -= beta * s * r
            
            if norm(r) < tol
                break
            end
        end
        
        alpha = -s / dot(p, r)
        beta = dot(p, r) / dot(p, p)
        
        x = x - alpha * p
        
        if norm(r) < tol
            break
        end
    end
    
    return x
end