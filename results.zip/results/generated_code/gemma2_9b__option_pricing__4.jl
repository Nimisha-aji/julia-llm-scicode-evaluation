using Random, Distributions

function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    mu = r - 0.5 * sigma^2
    S = zeros(n_paths, n_steps + 1)
    S[:, 1] .= S0
    
    for t in 2:(n_steps + 1)
        Z = randn(n_paths)
        S[:, t] .= S[:, t-1] .* exp.(mu * dt .+ sigma * sqrt(dt) .* Z)
    end
    
    payoff = max.(S[:, end] .- K, 0)
    price = exp(-r * T) * mean(payoff)
    return price
end