function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    Z = randn(n_paths, n_steps)
    S = fill(S0, (n_paths, n_steps + 1))
    for i in 1:n_steps
        drift = (r - 0.5 * sigma^2) * dt
        diffusion = sigma * sqrt(dt)
        S[:, i+1] .= S[:, i] .* exp.(drift .+ diffusion .* Z[:, i])
    end
    ST = S[:, end]
    payoff = max.(ST .- K, 0)
    price = exp(-r * T) * mean(payoff)
    return price
end