using Random

function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    dW = sqrt(dt) * randn(n_paths, n_steps)
    St = zeros(n_paths, n_steps + 1)
    St[:, 1] = S0
    for i in 1:n_steps
        St[:, i + 1] = St[:, i] * exp((r - 0.5 * sigma^2) * dt + sigma * dW[:, i])
    end
    payoff = maximum(St, dims = 2) .- K
    payoff[payoff .< 0] .= 0
    call_price = exp(-r * T) * mean(payoff)
    return call_price
end

# Example usage
S0 = 100.0
K = 105.0
r = 0.05
sigma = 0.2
T = 1.0
n_paths = 10000
n_steps = 100
println(black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps))