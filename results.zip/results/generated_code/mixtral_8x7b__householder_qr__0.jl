function householder_qr(A::Matrix)
    n, m = size(A)
    Q = similar(A, n, m)
    R = A

    for i in 1:m-1
        u = A[i,:]
        u_norm = norm(u)

        if u_norm == 0
            continue
        end