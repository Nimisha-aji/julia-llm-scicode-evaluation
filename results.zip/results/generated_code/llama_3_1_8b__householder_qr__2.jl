function householder_qr(A)
    n, m = size(A)
    Q = I(n)
    R = copy(A)
    for j in 1:min(n, m)
        v = R[j:n, j]
        v = v - sign(v[1]) * norm(v) * ones(n - j + 1)
        v = v / norm(v)
        R[j:n, j:n] -= 2 * v * v'
        Q *= I(n) - 2 * v * v'
    end
    return Q, R
end