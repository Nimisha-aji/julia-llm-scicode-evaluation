function ica_demix(X::AbstractMatrix, n_components::Int, max_iter::Int, tol::Float64)
    Random.seed!(42)

    # Center the data
    Xc = X .- mean(X, dims=2)

    # Whitening
    n_samples = size(Xc, 2)
    covX = (Xc * Xc') / (n_samples - 1)
    evals, evecs = eigen(covX)
    idx = sortperm(evals, rev=true)[1:n_components]
    D = Diagonal(evals[idx])
    E = evecs[:, idx]
    whitening = inv(sqrt.(D)) * E'
    Xw = whitening * Xc

    # Initialize demixing matrix
    W = randn(n_components, n_components)

    # Symmetric decorrelation
    decorrelate(A) = begin
        C = A * A'
        evals_c, evecs_c = eigen(C)
        (evecs_c * Diagonal(1 ./ sqrt.(evals_c)) * evecs_c') * A
    end