function supg_tau(u::Float64, kappa::Float64, h::Float64)::Float64
    return h / (2 * abs(u) + 4 * kappa / h)
end