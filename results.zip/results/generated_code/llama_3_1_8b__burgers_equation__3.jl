function burgers_solver(nu, nx, nt, dx, dt)
    u = zeros(nx)
    u[1] = 1.0
    u[2] = 0.5

    for it in 1:nt
        for i in 2:nx-1
            u[i] = u[i] - dt/dx * (u[i] - u[i-1]) + nu * dt / dx^2 * (u[i+1] - 2*u[i] + u[i-1])
        end
        u[1] = 1.0
        u[nx] = 0.0
    end

    return u
end