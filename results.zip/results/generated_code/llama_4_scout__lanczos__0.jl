function lanczos(A, v0, k)
    n = length(v0)
    v = [similar(v0) for _ in 1:k]
    v[1] = v0 ./ norm(v0)
    alpha = zeros(k)
    beta = zeros(k-1)

    v[1] = A * v[1]
    alpha[1] = dot(v[1], v[1])
    v[1] -= alpha[1] * v[1]

    for i in 1:k-1
        w = A * v[i]
        alpha[i+1] = dot(w, v[i])
        w -= alpha[i+1] * v[i] + beta[i] * v[i-1] if i > 1
        beta[i] = norm(w)
        v[i+1] = w ./ beta[i] if beta[i] > 0 else zeros(n)
    end

    return (alpha, beta)
end