function lanczos(A, v0, k)

    n = length(v0)

    v_prev = v0 / norm(v0)

    alpha = Vector{Float64}(undef, k)

    beta = Vector{Float64}(undef, k)

    beta_prev = 0.0

    v_prev_prev = similar(v0)

    for i in 1:k

        w = A * v_prev

        alpha_i = dot(v_prev, w)

        w .= w .- alpha_i * v_prev

        if i > 1

            w .= w .- beta_prev * v_prev_prev

        end

        beta_i = norm(w)

        alpha[i] = alpha_i

        beta[i] = beta_i

        # Update vectors

        v_prev_prev .= v_prev

        v_prev .= w ./ beta_i

        beta_prev = beta_i

    end

    return (alpha, beta)

end