function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    n = length(b)
    D = diagm(A)
    R = Diagonal(D) - A
    x = copy(x0)
    for _ in 1:max_iter
        x_new = (1 - omega) .* x + omega .* (b - R * x) ./ D
        if norm(x_new - x) < tol
            return x_new
        end
        x = x_new
    end
    return x
end