using Random

function ica_demix(X, n_components, max_iter, tol)
    Random.seed!(42)
    n_samples, n_features = size(X)
    X = (X .- mean(X, dims=1)) ./ std(X, dims=1)
    W = randn(n_components, n_components)
    for iter in 1:max_iter
        W_new = similar(W)
        for i in 1:n_components
            w = W[i, :]
            w .= w ./ norm(w)
            x = X * w
            g = tanh.(x)
            g_prime = 1 ./ cosh.(x).^2
            W_new[i, :] .= (I(n_components) - W' * W)[i, :] + mean(x .* g)
        end
        W = W_new
        if norm(W - W_new) < tol
            break
        end
    end
    return W
end