function supg_tau(u, kappa, h)
    c = maximum(abs.(u))
    tau = kappa / (c * h)
    return tau
end