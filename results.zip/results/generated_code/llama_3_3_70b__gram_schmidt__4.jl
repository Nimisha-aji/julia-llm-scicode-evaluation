using LinearAlgebra

function gram_schmidt(A)
    m, n = size(A)
    Q = zeros(m, n)
    for j = 1:n
        v = A[:, j]
        for i = 1:j-1
            q = Q[:, i]
            v = v - dot(q, v) * q
        end
        Q[:, j] = v / norm(v)
    end
    return Q
end

# Example usage:
A = rand(3, 3)
Q = gram_schmidt(A)
println(Q)