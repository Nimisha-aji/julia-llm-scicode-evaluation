function householder_qr(A::Matrix{<:Number})
    n, m = size(A)
    Q = similar(A, n, m)
    R = A

    for i in 1:m
        e = A[i, i]
        if e == 0
            return Q, R
        end