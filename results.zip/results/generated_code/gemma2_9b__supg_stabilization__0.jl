function supg_tau(u::Float64, kappa::Float64, h::Float64)::Float64
    return h / (2 * abs(u) + 2 * sqrt(kappa^2 + u^2 * h^2 / 16))
end