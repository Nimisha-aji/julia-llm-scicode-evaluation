function supg_tau(u, kappa, h)
    return 1.0 / sqrt((2u/h)^2 + (4kappa/(h^2))^2)
end