using LinearAlgebra

function lanczos(A::AbstractMatrix, v0::AbstractVector, k::Int)
    n = size(A, 1)
    @assert size(A, 2) == n "A must be square"
    @assert length(v0) == n "v0 size mismatch"
    @assert k ≥ 1 "k must be positive"

    v_prev = zeros(eltype(A), n)
    v = v0 / norm(v0)
    α = Vector{eltype(A)}(undef, k)
    β = Vector{eltype(A)}(undef, k-1)

    for j in 1:k
        w = A * v
        α[j] = dot(v, w)
        w .-= α[j] * v
        if j > 1
            w .-= β[j-1] * v_prev
        end
        if j < k
            β[j] = norm(w)
            if β[j] ≈ 0
                # Early termination: invariant subspace reached
                α = α[1:j]
                β = β[1:j-1]
                break
            end
            v_prev .= v
            v .= w / β[j]
        end
    end
    return (α, β)
end