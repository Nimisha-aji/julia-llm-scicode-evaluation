function householder_qr(A::Matrix{<:Number})
    n, m = size(A)
    Q = similar(A, n, m)
    R = A

    for i in 1:m-1
        v = A[i,:]
        v_norm = norm(v)

        if v_norm == 0
            continue
        end