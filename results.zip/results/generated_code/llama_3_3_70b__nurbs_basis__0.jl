function nurbs_basis(i, p, t, knots)
    if p == 0
        if knots[i] <= t < knots[i+1]
            return 1.0
        else
            return 0.0
        end
    else
        d1 = knots[i+p] - knots[i]
        e1 = t - knots[i]
        d2 = knots[i+p+1] - knots[i+1]
        e2 = knots[i+p+1] - t

        if d1 == 0.0 && e1 == 0.0
            return 0.0
        elseif d2 == 0.0 && e2 == 0.0
            return 0.0
        elseif d1 == 0.0
            return (p / (p+1)) * nurbs_basis(i+1, p, t, knots)
        elseif d2 == 0.0
            return (p / (p+1)) * nurbs_basis(i, p, t, knots)
        else
            return ((e1 / d1) * nurbs_basis(i, p-1, t, knots) + 
                    (e2 / d2) * nurbs_basis(i+1, p-1, t, knots))
        end
    end
end