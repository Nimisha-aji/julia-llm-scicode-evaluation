function pendulum_rk4(theta0, omega0, dt, nt, g, L, b)
    θ = theta0
    ω = omega0
    
    function f(θ, ω)
        return [g * L * cos(θ), -g * L * sin(θ) * cos(ω), -g * L * sin(θ) * sin(ω)]
    end