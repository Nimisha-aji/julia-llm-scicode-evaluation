function burgers_solver(nu, nx, nt, dx, dt)
    # Initialize u with some initial condition
    x = range(0, step=dx, length=nx)
    u = [i < 0.5 ? 1.0 : 0.0 for i in x]  # step function at x=0.5
    for n in 1:nt
        un = copy(u)
        for i in 2:nx-1
            # Compute convection term based on upwind
            if u[i] > 0
                convection = u[i]*(u[i] - u[i-1])/dx
            else
                convection = u[i]*(u[i+1] - u[i])/dx
            end
            # Compute diffusion term
            diffusion = nu*(u[i+1] - 2u[i] + u[i-1])/(dx^2)
            # Update un[i]
            un[i] = u[i] - dt*convection + dt*diffusion
        end
        # Apply boundary conditions (Dirichlet zero)
        un[1] = 0.0
        un[nx] = 0.0
        u = un
    end
    return u
end