function householder_qr(A)
    m, n = size(A)
    R = copy(A)
    Q = Matrix{eltype(A)}(I, m, m)

    for k in 1:min(m-1, n)
        x = R[k:end, k]
        σ = norm(x)
        if σ == 0
            continue
        end
        α = -sign(x[1]) * σ
        α = α == 0 ? -σ : α   # handle sign(0) case
        v = copy(x)
        v[1] -= α
        v_norm = norm(v)
        if v_norm == 0
            continue
        end
        v ./= v_norm

        # Apply Householder to R
        R[k:end, k:end] .-= 2 .* v * (v' * R[k:end, k:end])

        # Accumulate Q
        Q[:, k:end] .-= 2 .* (Q[:, k:end] * v) * v'
    end

    return Q, R
end