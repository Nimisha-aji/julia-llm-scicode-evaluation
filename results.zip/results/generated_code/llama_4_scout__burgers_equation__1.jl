function burgers_solver(nu, nx, nt, dx, dt)
    # Initialize solution vector
    u = zeros(nx)

    # Initial condition
    for i in 1:nx
        x = (i - 1) * dx
        u[i] = 1 - 2 * exp(-(x - 0.5)^2 / (4 * nu))
    end

    # Time-stepping
    for _ in 1:nt
        u_new = zeros(nx)
        for i in 2:nx
            u_new[i] = u[i] - dt / dx * u[i] * (u[i] - u[i-1])
        end
        u_new[1] = u[1] - dt / dx * u[1] * (u[1] - 0)
        u = u_new
    end

    return u
end

# Example usage
nu = 0.1
nx = 100
nt = 100
dx = 1.0 / (nx - 1)
dt = 0.9 * dx
u = burgers_solver(nu, nx, nt, dx, dt)