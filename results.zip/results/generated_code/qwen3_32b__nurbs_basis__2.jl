function nurbs_basis(i, p, t, knots)
    if p == 0
        return (knots[i] ≤ t < knots[i+1]) ? 1.0 : 0.0
    else
        term1 = 0.0
        denom1 = knots[i+p] - knots[i]
        if denom1 != 0
            term1 = (t - knots[i])/denom1 * nurbs_basis(i, p-1, t, knots)
        end
        denom2 = knots[i+p+1] - knots[i+1]
        term2 = 0.0
        if denom2 != 0
            term2 = (knots[i+p+1] - t)/denom2 * nurbs_basis(i+1, p-1, t, knots)
        end
        return term1 + term2
    end
end