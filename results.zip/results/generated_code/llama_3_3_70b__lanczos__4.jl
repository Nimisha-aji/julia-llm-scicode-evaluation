function lanczos(A, v0, k)
    n = size(A, 1)
    Q = zeros(n, k+1)
    Q[:, 1] = v0 / norm(v0)
    alpha = zeros(k)
    beta = zeros(k)
    q = zeros(n)
    for i = 1:k
        q = A * Q[:, i]
        for j = 1:i
            alpha[j] += dot(Q[:, j], q)
            q -= alpha[j] * Q[:, j]
        end
        if i < k
            beta[i] = norm(q)
            Q[:, i+1] = q / beta[i]
        end
    end
    return alpha, beta
end