function pendulum_rk4(theta0, omega0, dt, nt, g, L, b)
    theta = theta0
    omega = omega0
    angles = [theta]
    for _ in 1:nt
        k1θ = omega * dt
        k1ω = (- (b/L)*omega - (g/L)*sin(theta)) * dt
        
        θ2 = theta + k1θ/2
        ω2 = omega + k1ω/2
        k2θ = ω2 * dt
        k2ω = (- (b/L)*ω2 - (g/L)*sin(θ2)) * dt
        
        θ3 = theta + k2θ/2
        ω3 = omega + k2ω/2
        k3θ = ω3 * dt
        k3ω = (- (b/L)*ω3 - (g/L)*sin(θ3)) * dt
        
        θ4 = theta + k3θ
        ω4 = omega + k3ω
        k4θ = ω4 * dt
        k4ω = (- (b/L)*ω4 - (g/L)*sin(θ4)) * dt
        
        theta += (k1θ + 2k2θ + 2k3θ + k4θ)/6
        omega += (k1ω + 2k2ω + 2k3ω + k4ω)/6
        
        push!(angles, theta)
    end
    return angles
end