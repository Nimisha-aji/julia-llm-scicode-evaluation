function cg_solver(A, b, x0, tol)
    x = copy(x0)
    r = b - A * x
    p = r
    rsold = r' * r
    tolerance = tol^2
    while rsold > tolerance
        Ap = A * p
        alpha = rsold / (p' * Ap)
        x .= x .+ alpha .* p
        r .= r .- alpha .* Ap
        rsnew = r' * r
        beta = rsnew / rsold
        p .= r .+ beta .* p
        rsold = rsnew
    end
    return x
end