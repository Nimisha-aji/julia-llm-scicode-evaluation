function incomplete_cholesky(A, drop_tol=1e-4, fillin=0)
    n = size(A, 1)
    L = zeros(n, n)
    Ldiag = zeros(n)
    stack = 1:n
    while !isempty(stack)
        i = pop!(stack)
        if i > 1
            j = findfirst(x -> x == 0, L[i, 1:i-1])
            if j === nothing
                j = i-1
            end
            L[i, j] = sqrt(A[i, i] - sum(L[i, 1:j-1]^2))
            Ldiag[i] = L[i, i]
            if L[i, i] < drop_tol * Ldiag[i-1]
                push!(stack, i)
            else
                for k = j+1:i-1
                    L[i, k] = (A[i, k] - L[i, 1:j-1]*L[k, 1:j-1]) / Ldiag[i]
                    if L[i, k] != 0
                        if fillin > 0
                            L[k, i] = L[i, k]
                        end
                        push!(stack, k)
                    end
                end
            end
        else
            Ldiag[1] = sqrt(A[1, 1])
        end
    end
    return L
end