function cg_solver(A::Array{T,2}, b::Array{T,1}, x0::Array{T,1}, tol::T) where {T<:Number}
    n, m = size(A)
    x = x0
    α = ones(T, m)
    β = ones(T, m)
    γ = ones(T, m)
    
    while true
        p = A * x
        q = b - p
        x = (α * q) / dot(q, q)
        
        if norm(q) < tol
            break
        end
        
        p = A * x
        q = b - p
        x = (β * q) / dot(q, q)
        
        γ = (A * x) .* γ
        α = (A * x) .* p / dot(p, p)
    end
    
    return x
end