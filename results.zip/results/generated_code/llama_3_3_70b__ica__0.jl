using LinearAlgebra
using Random

function ica_demix(X, n_components, max_iter, tol)
    Random.seed!(42)
    n_samples, n_features = size(X)
    W = randn(n_components, n_features)
    W ./= sqrt.(sum(W.^2, dims=2))
    for _ in 1:max_iter
        old_W = copy(W)
        for i in 1:n_components
            w = W[i, :]
            wX = w' * X
            g = 3 * wX.^3 - wX
            g_w = (1 / n_samples) * X * g
            g_w -= (1 / n_samples) * sum(g) * w
            w_new = g_w - w * (w' * g_w)
            w_new ./= sqrt(sum(w_new.^2))
            W[i, :] = w_new
        end
        W, _ = qr(W)
        if norm(W - old_W) < tol
            break
        end
    end
    return W
end