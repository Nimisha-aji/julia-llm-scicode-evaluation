using LinearAlgebra

function lanczos(A::AbstractMatrix, v0::AbstractVector, k::Int)
    n = length(v0)
    @assert size(A,1) == n && size(A,2) == n "A must be square and match length of v0"
    q_prev = zeros(eltype(v0), n)
    q = v0 / norm(v0)
    α = zeros(eltype(v0), k)
    β = zeros(eltype(v0), k-1)

    for j in 1:k
        w = A * q - (j > 1 ? β[j-1] * q_prev : zero(q))
        α[j] = dot(q, w)
        w .-= α[j] * q
        if j < k
            βj = norm(w)
            β[j] = βj
            if βj == 0
                # early termination
                α = α[1:j]
                β = β[1:j-1]
                break
            end
            q_prev .= q
            q .= w / βj
        end
    end
    return (α, β)
end