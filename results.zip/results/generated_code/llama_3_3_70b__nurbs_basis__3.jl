function nurbs_basis(i::Int, p::Int, t::Float64, knots::Vector{Float64})::Float64
    if p == 0
        if knots[i] <= t < knots[i+1]
            return 1.0
        else
            return 0.0
        end
    else
        d1 = t - knots[i]
        d2 = knots[i+p+1] - t
        e1 = knots[i+p+1] - knots[i]
        e2 = knots[i+p+2] - knots[i+1]
        
        if e1 == 0.0
            b1 = 0.0
        else
            b1 = d1 / e1 * nurbs_basis(i, p-1, t, knots)
        end
        
        if e2 == 0.0
            b2 = 0.0
        else
            b2 = d2 / e2 * nurbs_basis(i+1, p-1, t, knots)
        end
        
        return b1 + b2
    end
end