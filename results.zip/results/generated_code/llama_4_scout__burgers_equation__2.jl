function burgers_solver(nu, nx, nt, dx, dt)
    # Initialize solution vector
    u = zeros(nx)

    # Set initial condition
    for i in 1:nx
        x = (i - 1) * dx
        u[i] = 1 - 2 * exp(-(x - 0.5)^2 / (4 * nu))
    end

    # Time-stepping
    for _ in 1:nt
        u_new = zeros(nx)
        for i in 2:nx
            flux = u[i-1]^2 / 2
            u_new[i] = u[i] - dt / dx * (flux - u[i]^2 / 2)
        end
        u_new[1] = u_new[2]
        u .= u_new
    end

    return u
end