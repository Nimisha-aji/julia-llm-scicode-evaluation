function burgers_solver(nu, nx, nt, dx, dt)
    # Initialize solution vector
    u = zeros(nx, nt)

    # Initial condition
    x = range(0, stop=1, length=nx)
    u[:, 1] = sin.(2 .* π .* x)

    # Upwind finite differences
    for n in 1:nt-1
        for i in 2:nx
            u[i, n+1] = u[i, n] - u[i, n] * dt / dx * (u[i, n] - u[i-1, n]) + nu * dt / dx^2 * (u[i+1, n] - 2u[i, n] + u[i-1, n])
        end
        u[1, n+1] = u[1, n] - u[1, n] * dt / dx * (u[1, n] - u[end, n]) + nu * dt / dx^2 * (u[2, n] - 2u[1, n] + u[end, n])
        if nx > 1
            u[end, n+1] = u[end, n] - u[end, n] * dt / dx * (u[end, n] - u[end-1, n]) + nu * dt / dx^2 * (u[1, n] - 2u[end, n] + u[end-1, n])
        end
    end

    return u
end