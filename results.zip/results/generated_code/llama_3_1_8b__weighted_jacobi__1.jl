function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    n = size(A, 1)
    D = diag(A)
    R = A - diagm(D)
    x = copy(x0)
    for i in 1:max_iter
        x_new = copy(x)
        for j in 1:n
            s = 0
            for k in 1:n
                if k != j
                    s += R[j, k] * x[k]
                end
            end
            x_new[j] = (1 - omega) * x[j] + omega * (b[j] - s) / D[j]
        end
        if norm(x_new - x) < tol
            return x_new
        end
        x = x_new
    end
    return x
end