function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    D = diag(A)
    x = copy(x0)
    for k in 1:max_iter
        r = b - A * x
        x_new = x + omega * (r ./ D)
        if norm(x_new - x, Inf) < tol
            return x_new
        end
        x = x_new
    end
    return x
end