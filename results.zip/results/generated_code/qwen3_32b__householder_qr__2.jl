function householder_qr(A)
    m, n = size(A)
    Q = Matrix{Float64}(I, m, m)
    R = copy(A)
    for i in 1:n
        x = view(R, i:m, i)
        sigma = norm(x)
        if sigma == 0
            continue
        end
        alpha = -sign(x[1]) * sigma
        v = similar(x)
        v[1] = x[1] - alpha
        v[2:end] = view(x, 2:end)
        # Compute beta
        beta = 2 / (v' * v)
        # Apply transformation to R
        for j in i:n
            aj = view(R, i:m, j)
            tau = dot(aj, v)
            R[i:m, j] .= aj .- beta * tau .* v
        end
        # Apply transformation to Q
        for j in 1:m
            qj = view(Q, i:m, j)
            tau = dot(qj, v)
            Q[i:m, j] .= qj .- beta * tau .* v
        end
    end
    return Q, R
end