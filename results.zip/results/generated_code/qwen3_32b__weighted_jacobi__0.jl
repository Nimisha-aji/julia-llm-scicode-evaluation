function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    n = length(b)
    x = copy(x0)
    diag_A = diag(A)
    for _ in 1:max_iter
        r = b - A * x
        D_inv_r = r ./ diag_A
        x_new = x + omega * D_inv_r
        if norm(x_new - x) < tol
            return x_new
        end
        x = x_new
    end
    return x
end