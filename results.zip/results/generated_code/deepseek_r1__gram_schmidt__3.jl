function gram_schmidt(A::AbstractMatrix)
    m, n = size(A)
    Q = similar(A, m, n)
    for j in 1:n
        v = A[:, j]
        for i in 1:j-1
            proj = dot(Q[:, i], v)
            v .-= proj .* Q[:, i]
        end
        normv = norm(v)
        if normv == 0
            error("Matrix A has linearly dependent columns")
        end
        Q[:, j] = v / normv
    end
    return Q
end