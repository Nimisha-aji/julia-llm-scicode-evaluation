function householder_qr(A)
    m, n = size(A)
    R = copy(A)
    Q = Matrix{eltype(A)}(I, m, m)

    for k in 1:min(m-1, n)
        x = R[k:end, k]
        α = -norm(x) * (x[1] >= 0 ? 1 : -1)
        v = copy(x)
        v[1] -= α
        v_norm = norm(v)
        if v_norm ≈ 0
            continue
        end
        v ./= v_norm

        # Apply reflector to R
        R[k:end, k:end] .-= 2 .* v * (v' * R[k:end, k:end])

        # Accumulate reflector into Q
        Q[:, k:end] .-= 2 .* (Q[:, k:end] * v) * v'
    end

    return Q, R
end