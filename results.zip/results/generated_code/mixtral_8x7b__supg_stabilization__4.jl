function s upg_tau(u, kappa, h)
    return sqrt(kappa / h) * (1 + kappa / (2 * h^2))
end