using LinearAlgebra

function gauss_seidel(A, b, x0, tol, max_iter)
    n = length(b)
    x = copy(x0)
    for _ in 1:max_iter
        x_new = copy(x)
        for i in 1:n
            sum_lower = dot(A[i,1:i-1], x_new[1:i-1])
            sum_upper = dot(A[i,i+1:end], x[i+1:end])
            x_new[i] = (b[i] - sum_lower - sum_upper) / A[i,i]
        end
        if norm(x_new - x) < tol
            return x_new
        end
        x = x_new
    end
    return x
end