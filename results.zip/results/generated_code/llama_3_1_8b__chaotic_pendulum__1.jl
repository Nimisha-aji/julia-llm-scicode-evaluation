function pendulum_rk4(theta0, omega0, dt, nt, g, L, b)
    theta = zeros(nt + 1)
    omega = zeros(nt + 1)
    theta[1] = theta0
    omega[1] = omega0
    for i in 1:nt
        k1_theta = omega[i]
        k1_omega = -(g/L)*sin(theta[i]) - b*omega[i]/L
        k2_theta = omega[i] + 0.5*dt*k1_omega
        k2_omega = -(g/L)*sin(theta[i] + 0.5*dt*k1_theta) - b*omega[i]/L
        k3_theta = omega[i] + 0.5*dt*k2_omega
        k3_omega = -(g/L)*sin(theta[i] + 0.5*dt*k2_theta) - b*omega[i]/L
        k4_theta = omega[i] + dt*k3_omega
        k4_omega = -(g/L)*sin(theta[i] + dt*k3_theta) - b*omega[i]/L
        theta[i + 1] = theta[i] + (dt/6)*(k1_theta + 2*k2_theta + 2*k3_theta + k4_theta)
        omega[i + 1] = omega[i] + (dt/6)*(k1_omega + 2*k2_omega + 2*k3_omega + k4_omega)
    end
    return theta
end