using SparseArrays

function incomplete_cholesky(A::SparseMatrixCSC{T}) where T<:Real
    n = size(A, 1)
    @assert n == size(A, 2) "Matrix must be square"
    L = spzeros(T, n, n)

    for i in 1:n
        # Get nonzero rows in column i of A (including diagonal)
        col_start = A.colptr[i]
        col_end   = A.colptr[i+1] - 1
        rows = A.rowval[col_start:col_end]

        for j in rows
            j > i && continue          # only lower triangular part
            # Compute the dot product sum_{k=1}^{j-1} L[i,k] * L[j,k]
            s = zero(T)
            if j > 1
                # intersect nonzero pattern of rows i and j up to column j-1
                k_start = L.colptr[1]
                k_end   = L.colptr[j] - 1
                # iterate over columns k < j where both L[i,k] and L[j,k] are nonzero
                for k in 1:j-1
                    L_ik = L[i,k]
                    L_jk = L[j,k]
                    if L_ik != zero(T) && L_jk != zero(T)
                        s += L_ik * L_jk
                    end
                end
            end

            a_ij = A[j,i]
            if i == j
                val = a_ij - s
                @assert val > zero(T) "Matrix not positive definite at diagonal $i"
                L[i,i] = sqrt(val)
            else
                @assert L[j,j] != zero(T) "Zero diagonal encountered at $j"
                L[i,j] = (a_ij - s) / L[j,j]
            end
        end
    end
    return L
end