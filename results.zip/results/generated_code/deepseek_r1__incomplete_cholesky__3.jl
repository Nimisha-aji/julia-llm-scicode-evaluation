function incomplete_cholesky(A::SparseMatrixCSC{T}) where T<:Real
    n = size(A, 1)
    @assert n == size(A, 2) "Matrix must be square"
    Lvals = Dict{Tuple{Int,Int},T}()

    for col in 1:n
        # iterate rows i >= col where A[i,col] ≠ 0
        for ptr in A.colptr[col]:(A.colptr[col+1]-1)
            i = A.rowval[ptr]
            i < col && continue          # skip upper part
            a_ij = A.nzval[ptr]

            # compute sum_{k<col} L[i,k] * L[col,k]
            s = zero(T)
            for k in 1:col-1
                li = get(Lvals, (i,k), nothing)
                lj = get(Lvals, (col,k), nothing)
                li === nothing && continue
                lj === nothing && continue
                s += li * lj
            end