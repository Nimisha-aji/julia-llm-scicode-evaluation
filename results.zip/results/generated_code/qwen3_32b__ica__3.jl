function g(s) = tanh(s)
3. Compute the derivative g_prime = 1 .- tanh.(s).^2
4. Update W using W = (X_white * g' ./ n - mean(g', dims=1) * W) * W
Wait, not sure. Let me look up the FastICA algorithm formula again.

The FastICA algorithm uses the following fixed-point iteration for each weight vector w:

w_new = (X' * tanh(w * X) / n) - (X' * (1 - tanh.(w * X).^2) .* (w * X)) / n) * w

But perhaps I'm mixing up different versions. Another source says that the update is:

w_new = E[X g'(w^T X)] - E[g''(w^T X)] * E[X] * w

But since the data is centered and whitened, E[X] is zero. So perhaps the update simplifies to:

w_new = E[X g'(w^T X)] - E[g''(w^T X)] * w

But for the tanh function, g''(s) = -2 tanh(s) (1 - tanh(s)^2). However, in practice, the FastICA algorithm uses a different approach. Let me refer to the original FastICA paper or a reliable source.

According to the FastICA algorithm description, the fixed-point iteration for the non-linear function g(s) = tanh(α s) with α=1 is:

w_new = (X' * tanh(W * X) / n) - diag(mean(tanh(W * X), ... )) * W

But I'm not confident. Let me try to find a code example for FastICA in base Julia.

Alternatively, here's a possible approach for the FastICA algorithm:

Initialize W as random orthogonal matrix.

For each iteration:

Compute s = W * X_white

Compute the non-linear function, say g(s) = tanh(s)

Compute the term for the update:

W_update = (X_white * (g' ./ size(X_white, 1)) - mean(g', dims=1) * W) * W

Wait, perhaps the correct update is:

W_new = (X_white' * tanh.(s) / n) - mean(tanh.(s), dims=1) * W

Then, orthogonalize W_new with respect to previous components.

But since W is supposed to be orthogonal (because of whitening), perhaps after updating each row, we need to subtract the projections onto the other rows.

This is getting complicated. Let me try to code this step by step.

Assuming that after whitening, the data is X_white. The demixing matrix W is initialized as an orthogonal matrix. For each iteration, compute s = W * X_white. Then compute the non-linear function and its derivative. The update for W is:

W_new = (X_white * tanh.(s)') / n - mean(tanh.(s), dims=1) * W

Wait, perhaps not. Let me think again. The standard FastICA algorithm uses the following update for each weight vector w:

w_new = E[X g'(w^T X)] - E[g''(w^T X)] * w

But since the data is whitened, the components are uncorrelated, and the algorithm can proceed by deflation.

Alternatively, here's a possible code outline for the FastICA algorithm:

Initialize W as random orthogonal matrix.

For each iteration:

    s = W * X_white
    g_prime = 1 .- tanh.(s).^2
    W_update = (X_white * (tanh.(s)') ./ n) - (mean(tanh.(s), dims=1) * W)
    W = W_update
    orthogonalize W

But I'm not sure. Another approach is to use the following update:

W_new = (X_white' * tanh.(W * X_white) / n) - diag(mean(tanh.(W * X_white), dims=1)) * W

Then, orthogonalize W_new.

But how to orthogonalize? Perhaps perform QR decomposition on W_new to make it orthogonal.

Alternatively, after each update, perform W = W - W * W' * W / 2 or something similar.

This is getting quite tricky. Let me try to find a minimal working example.

Another idea: the FastICA algorithm for one component can be implemented as follows. For multiple components, after extracting each component, subtract its contribution from the data. But since the user wants all components at once, perhaps the parallel version is needed.

In the parallel FastICA algorithm, the update for W is:

W = (X_white' * tanh(W * X_white) / n) * inv(diagm(mean(tanh.(W * X_white), dims=1))) - W * diagm(mean(tanh.(W * X_white), dims=1))

But I'm not sure. Alternatively, the update could be:

W_new = (X_white' * tanh.(W * X_white) / n) ./ (mean(tanh.(W * X_white), dims=1) .* ones(n_components, 1)) - W * diag(mean(tanh.(W * X_white), dims=1))

But this is getting too vague. Let me try to code it step by step.

Assuming that after whitening, the data is X_white. The demixing matrix W is initialized as a random orthogonal matrix. For each iteration:

Compute s = W * X_white

Compute the non-linear function, say g(s) = tanh(s)

Compute the derivative g_prime = 1 - tanh(s)^2

The update for W is:

W_new = (X_white' * g_prime) / n - mean(g_prime, dims=1) * W

Then, orthogonalize W_new.

Wait, perhaps the correct update is:

W_new = (X_white' * tanh.(s) / n) - mean(tanh.(s), dims=1) * W

But then multiply by W? Or something else.

Alternatively, the standard FastICA algorithm uses the following update for each weight vector w:

w_new = E[X g'(w^T X)] - E[g''(w^T X)] * w

But since the data is whitened, the second term might be omitted. Or perhaps not.

Given the time constraints, perhaps proceed with the following code:

Initialize W as random orthogonal matrix.

For each iteration:

    s = W * X_white
    g_s = tanh.(s)
    W_update = (X_white' * g_s) / n - mean(g_s, dims=1) * W
    W = W_update
    orthogonalize W

But how to orthogonalize? Perhaps perform QR decomposition on W and take the Q matrix.

But QR decomposition returns an orthogonal matrix, but we need to ensure that W remains orthogonal. So after each update, perform QR on W and set W = Q.

But in Julia, the qr function returns a Q matrix with orthonormal columns. So after updating W, we can do:

W = qr(W).Q

But this might change the signs of the columns. To handle that, we can multiply by the sign of the diagonal elements to ensure they are positive.

But perhaps for simplicity, just take the Q matrix from the QR decomposition.

Putting it all together:

function ica_demix(X, n_components, max_iter, tol)
    Random.seed!(42)
    n_samples, n_features = size(X)
    # Center X
    X_centered = X .- mean(X, dims=1)
    # Whiten X
    cov_X = (X_centered' * X_centered) / n_samples
    eigen_vals, eigen_vecs = eigen(cov_X)
    whitening_matrix = eigen_vecs * Diagonal(1 ./ sqrt.(eigen_vals)) * eigen_vecs'
    X_white = X_centered * whitening_matrix
    # Initialize W
    W = randn(n_components, n_components)
    Q, R = qr(W)
    W = Q
    # FastICA iterations
    for iter in 1:max_iter
        s = W * X_white
        g_s = tanh.(s)
        W_update = (X_white * g_s') / n_samples - mean(g_s, dims=2) * W
        # Orthogonalize W_update
        Q, R = qr(W_update)
        W_new = Q
        # Check convergence
        if maximum(abs.(W_new .- W)) < tol
            break
        end
        W = W_new
    end
    return W
end