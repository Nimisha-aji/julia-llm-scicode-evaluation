using LinearAlgebra

function incomplete_cholesky(A)
    n = size(A, 1)
    L = zeros(n, n)
    for j in 1:n
        for i in j:n
            if i == j
                L[i, j] = sqrt(A[i, j])
            else
                L[i, j] = A[i, j] / L[j, j]
            end
        end
    end
    return LowerTriangular(L)
end