function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    n = length(b)
    x = copy(x0)
    D = diag(diag(A))
    R = A - D
    for iter in 1:max_iter
        x_new = x - omega * (D \ (A * x - b))
        if norm(x_new - x) < tol
            return x_new
        end
        x = x_new
    end
    return x
end