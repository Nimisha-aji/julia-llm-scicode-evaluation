function householder_qr(A)
    m, n = size(A)
    R = copy(A)
    Q = Matrix{Float64}(I, m, m)
    for k in 1:n
        x = view(R, k:m, k)
        # Compute Householder vector u
        sigma = norm(x)
        if sigma == 0
            continue
        end
        v = similar(x)
        v .= x
        if x[1] > 0
            v[1] += sigma
        else
            v[1] -= sigma
        end
        # Normalize v?
        # Apply the reflection to R[k:m, k:n]
        # And to Q[:, k:m]
        # Compute the reflection matrix H = I - 2 * v * v' / (v'v)
        # But applying H to R and Q
        # For R:
        # H * R_submatrix
        # For each row i from k to m:
        # R[i, k:n] -= (2 * v' * R[i, k:n]) / (v' * v) * v
        # Similarly for Q:
        # H * Q[:, k:m]
        # So for each row i in Q's columns from k to m:
        # Q[i, k:m] -= (2 * v' * Q[i, k:m]) / (v'v) * v
        # But how to compute this efficiently?
        # Compute the denominator: v'v = sigma^2 + (sigma * x[1])^2 ? Wait, no. Let me compute v'v.

        # v is x + sign(x[1]) * sigma * e1. Let me compute v'v.

        # Let me compute v'v. Let me denote that as beta.

        beta = dot(v, v)
        # Then for each row i >=k in R:
        # R[i, k:end] -= (2 * dot(v, R[i, k:end]) / beta) * v
        # Similarly for Q.

        # So for the current submatrix R[k:m, k:end], we can loop over each row and apply this.

        # But in Julia, perhaps we can vectorize this.

        # However, for efficiency, perhaps we can use the fact that the first element of v is non-zero.

        # Let me compute the factor for each row.

        # For R:
        for j in k:m
            row = R[j, k:end]
            rho = 2 * dot(v, row) / beta
            R[j, k:end] -= rho * v
        end

        # For Q:
        for j in 1:m
            row = Q[j, k:m]
            rho = 2 * dot(v, row) / beta
            Q[j, k:m] -= rho * v[1:end]  # Wait, v is the same length as row?
        end
    end
    return Q, R
end