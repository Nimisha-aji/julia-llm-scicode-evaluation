function nurbs_basis(i, p, t, knots)
    if p == 0
        return (knots[i] ≤ t < knots[i+1]) ? 1.0 : 0.0
    else
        left_den = knots[i + p] - knots[i]
        left = left_den != 0 ? ((t - knots[i]) / left_den) * nurbs_basis(i, p-1, t, knots) : 0.0
        right_den = knots[i + p + 1] - knots[i + 1]
        right = right_den != 0 ? ((knots[i + p + 1] - t) / right_den) * nurbs_basis(i + 1, p-1, t, knots) : 0.0
        return left + right
    end
end