function supg_tau(u, kappa, h)
    Pe = abs.(u) .* h ./ (2 .* kappa)
    tau = h ./ (2 .* abs.(u)) .* (1 ./ sqrt.(1 .+ Pe.^2))
    return tau
end