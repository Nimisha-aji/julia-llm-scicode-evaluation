function nurbs_basis(i, p, t, knots)
    if t <= knots[i] || t >= knots[i+p+1]
        return 0.0
    elseif p == 0
        return 1.0
    else
        return (t - knots[i]) * nurbs_basis(i, p-1, t, knots) / (knots[i+p] - knots[i]) + (knots[i+p+1] - t) * nurbs_basis(i+1, p-1, t, knots) / (knots[i+p+1] - knots[i+1])
    end
end