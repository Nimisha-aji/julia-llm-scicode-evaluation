function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    
    # Calculate the Black-Scholes parameters
    σ = sigma * sqrt(T)
    rho = r - sigma^2 / T
    d1 = (log(S0 / K) + (r + σ^2 / 2) * T) / (σ * sqrt(T))
    d2 = d1 - σ * sqrt(T)
    
    # Monte Carlo simulation
    prices = Vector{Float64}(undef, n_paths)
    for i in 1:n_paths
        # Generate random paths
        x = randn(n_steps)
        
        # Calculate the option price for each path
        for j in 1:n_steps
            x[j] = x[j] * exp(-r * j + x[j] * σ * sqrt(j))
            d1_j = (log(S0 * x[j] / K) + (r + σ^2 / 2) * j) / (σ * sqrt(j))
            d2_j = d1_j - σ * sqrt(j)
            if d1_j > 0
                prices[i] += exp(-r * T) * K * sign(d2_j) * sqrt(T * j) * normcdf(-d1_j)
            end