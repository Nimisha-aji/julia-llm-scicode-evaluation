function strang_splitting(u0, dt, nt, L1, L2)
    u = u0
    for n in 1:nt
        u = exp(dt/2 * L1) * exp(dt * L2) * exp(dt/2 * L1) * u
    end
    return u
end