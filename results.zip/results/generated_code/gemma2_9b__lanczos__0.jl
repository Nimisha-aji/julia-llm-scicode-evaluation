function lanczos(A, v0, k)
    n = size(A, 1)
    v = [similar(v0) for i in 1:k+1]
    alpha = zeros(k)
    beta = zeros(k)
    
    v[1] = v0 / norm(v0)
    
    for i in 1:k
        w = A * v[i]
        if i > 1
            w -= beta[i-1] * v[i-1]
        end
        alpha[i] = dot(v[i], w)
        w -= alpha[i] * v[i]
        beta[i] = norm(w)
        v[i+1] = w / beta[i]
    end
    
    return (alpha, beta)
end