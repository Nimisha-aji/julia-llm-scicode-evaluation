function incomplete_cholesky(A)
    n = size(A, 1)
    L = zeros(n, n)

    for i in 1:n
        if A[i, i] < 0.0
            L[i, i] = sqrt(-A[i, i])
            for j in (i + 1):n
                L[j, i] = A[j, i] / L[i, i]
            end