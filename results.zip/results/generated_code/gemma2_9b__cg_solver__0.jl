function cg_solver(A, b, x0, tol)
    x = copy(x0)
    r = b - A * x
    p = copy(r)
    rsold = r' * r

    for i in 1:length(b)
        Ap = A * p
        alpha = rsold / (p' * Ap)
        x .= x .+ alpha .* p
        r .= r .- alpha .* Ap
        rsnew = r' * r
        if sqrt(rsnew) < tol
            break
        end
        beta = rsnew / rsold
        p = r + beta * p
        rsold = rsnew
    end

    return x
end