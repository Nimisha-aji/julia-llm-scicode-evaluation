function gauss_seidel(A, b, x0, tol, max_iter)
    n = size(A, 1) # number of variables
    x = zeros(n) # initial guess for solution vector
    x[1] = x0[1] # initialize first element

    for iter in 1:max_iter
        for i in 2:n
            x[i] = (1 / A[i, i]) * sum(A[i, j] * x[j] for j in 1:i-1)
        end