function supg_tau(u, kappa, h)
    term = 2 * kappa * u / h^2
    sqrt_term = sqrt(1 + term^2)
    tau = h / (2u) / (1 + sqrt_term)
    return tau
end