function incomplete_cholesky(A::SparseMatrixCSC{T}) where T<:Real
    n = size(A, 1)
    L = spzeros(T, n, n)
    for i in 1:n
        col_i_rows, _, col_i_vals = findnz(view(A, :, i))
        for (j, aij) in zip(col_i_rows, col_i_vals)
            j > i && continue          # only lower triangle (including diagonal)
            s = aij
            # subtract contributions from previously computed entries
            for k in 1:j-1
                ljk = L[j, k]
                lik = L[i, k]
                if ljk != 0 && lik != 0
                    s -= ljk * lik
                end
            end
            if i == j
                if s <= 0
                    error("Matrix is not positive definite at diagonal $i")
                end
                L[i, i] = sqrt(s)
            else
                if L[j, j] == 0
                    error("Zero pivot encountered at $j")
                end
                L[i, j] = s / L[j, j]
            end
        end
    end
    return L
end