using LinearAlgebra

function householder_qr(A::AbstractMatrix)
    m, n = size(A)
    R = copy(A)
    Q = Matrix{eltype(A)}(I, m, m)

    for k = 1:min(m-1, n)
        # Extract the vector to reflect
        x = R[k:end, k]
        α = norm(x)
        α = x[1] ≥ 0 ? -α : α   # choose sign to avoid cancellation
        v = x
        v[1] -= α
        β = v' * v
        if β ≈ 0
            continue
        end
        v = v / sqrt(β)

        # Apply Householder to R (from the left)
        R[k:end, k:end] .-= 2 .* (v * (v' * R[k:end, k:end]))

        # Accumulate Q
        Q[:, k:end] .-= 2 .* (Q[:, k:end] * v) * v'
    end

    # Trim R to upper triangular shape (zero out tiny lower part)
    for i = 2:m
        for j = 1:min(i-1, n)
            R[i, j] = zero(eltype(R))
        end
    end

    return Q, R
end