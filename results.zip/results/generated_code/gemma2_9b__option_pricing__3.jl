using Random, Distributions

function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    St = zeros(n_paths, n_steps + 1)
    St[:, 1] .= S0
    Z = randn(n_paths, n_steps)
    
    for t in 1:n_steps
        St[:, t+1] = St[:, t] .* exp((r - 0.5 * sigma^2) * dt .+ sigma * sqrt(dt) .* Z[:, t])
    end
    
    payoffs = max.(St[:, end] .- K, 0)
    price = exp(-r * T) * mean(payoffs)
    return price
end