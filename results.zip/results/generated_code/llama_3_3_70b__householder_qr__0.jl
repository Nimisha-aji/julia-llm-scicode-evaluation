function householder_qr(A)
    m, n = size(A)
    Q = eye(m)
    R = copy(A)
    for j = 1:min(m-1, n)
        x = view(R, j:m, j)
        e1 = zeros(m-j+1)
        e1[1] = 1
        v = x .- norm(x) * e1
        v[1] += sign(x[1]) * norm(x)
        v = v / norm(v)
        H = eye(m)
        H[j:m, j:m] .= eye(m-j+1) - 2 * v * v'
        Q = H * Q
        R = H * R
    end
    return Q, R
end