function cg_solver(A, b, x0, tol)
    x = copy(x0)
    r = b - A * x
    p = r
    rs_old = r' * r
    while sqrt(rs_old) > tol
        Ap = A * p
        alpha = rs_old / (p' * Ap)
        x += alpha * p
        r -= alpha * Ap
        rs_new = r' * r
        beta = rs_new / rs_old
        p = r + beta * p
        rs_old = rs_new
    end
    return x
end