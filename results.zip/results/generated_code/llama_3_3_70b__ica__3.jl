using LinearAlgebra
using Random

function ica_demix(X, n_components, max_iter, tol)
    Random.seed!(42)
    n_samples, n_features = size(X)
    W = randn(n_components, n_features)
    W ./= sqrt.(sum(W.^2, dims=2))
    for _ in 1:max_iter
        old_W = copy(W)
        for i in 1:n_components
            w = W[i, :]
            wX = w' * X
            g = -2 * tanh.(wX)
            g_prime = 1 .- tanh.(wX).^2
            delta = (g * X') / n_samples - g_prime' * w
            w .= w .+ delta
            w ./= sqrt(sum(w.^2))
            W[i, :] = w
        end
        if norm(W - old_W) < tol
            break
        end
    end
    return W
end