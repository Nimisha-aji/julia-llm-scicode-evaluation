function householder_qr(A)
    m, n = size(A)
    Q = I(m)
    R = copy(A)
    for j in 1:min(m, n)
        v = view(R, j:m, j)
        e1 = ones(eltype(v), length(v))
        e1[j:end] .= 0
        v .= v .- 2 * norm(v) * e1 / norm(e1)
        Qv = view(Q, j:m, j:m)
        Qv .= Qv .- 2 * (Qv' * v) * v / (v' * v)
        for k in 1:j-1
            view(R, k:j-1, j) .= R[k:j-1, j] - (Qv[k:j-1, j] * R[j:m, j])
        end
        R[j:m, j:m] .= R[j:m, j:m] - (Qv * (Qv' * R[j:m, j:m]))
        R[j:m, j] .= R[j:m, j] / norm(R[j:m, j])
        R[j:m, j:m] .= R[j:m, j:m] - R[j:m, j] * R[j:m, j]'
    end
    return Q, R
end