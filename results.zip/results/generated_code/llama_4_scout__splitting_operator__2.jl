function strang_splitting(u0, dt, nt, L1, L2)
    u = copy(u0)
    for _ in 1:nt
        # First half-step with L1
        u = u - 0.5 * dt * L1 * u
        
        # Full step with L2
        u = u - dt * L2 * u
        
        # Second half-step with L1
        u = u - 0.5 * dt * L1 * u
    end
    return u
end