using LinearAlgebra
using Random
using Statistics

function ica_demix(X::AbstractMatrix, n_components::Int, max_iter::Int, tol::Float64)
    # Ensure reproducibility
    Random.seed!(42)

    # Center the data (rows = samples, cols = features)
    Xc = X .- mean(X, dims=1)

    # Whiten the data
    covX = cov(Xc, dims=1)
    F = eigen(covX)
    D = Diagonal(1 ./ sqrt.(F.values[1:n_components]))
    E = F.vectors[:, 1:n_components]
    whitening = D * E'                     # (n_components × n_features)
    Xw = Xc * whitening'                   # (n_samples × n_components)

    # Initialize random demixing matrix
    W = randn(n_components, n_components)

    # Symmetric decorrelation function
    decorrelate!(M) = begin
        S = M * M'
        E, V = eigen(S)
        M .= (V * Diagonal(1 ./ sqrt.(E)) * V') * M
    end

    decorrelate!(W)

    for _ in 1:max_iter
        W_old = copy(W)

        # Fixed-point iteration with tanh nonlinearity
        Y = Xw * W'                         # (n_samples × n_components)
        G = tanh.(Y)
        G_prime = 1 .- G.^2

        # Update rule
        W = (G' * Xw) ./ size(Xw, 1) .- Diagonal(mean(G_prime, dims=1)) * W

        # Decorrelate
        decorrelate!(W)

        # Check convergence
        delta = maximum(abs.(abs.(diag(W * W_old')) .- 1.0))
        if delta < tol
            break
        end
    end

    # Overall demixing matrix (maps original X to independent components)
    return W * whitening
end