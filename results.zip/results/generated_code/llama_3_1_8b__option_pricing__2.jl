function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    dW = sqrt(dt) * randn(n_paths, n_steps)
    St = zeros(n_paths, n_steps + 1)
    St[:, 1] = S0
    for i in 1:n_steps
        St[:, i + 1] = St[:, i] * exp((r - 0.5 * sigma^2) * dt + sigma * dW[:, i])
    end
    payoff = max.(St[:, end] - K, 0)
    call_price = mean(payoff)
    return call_price
end