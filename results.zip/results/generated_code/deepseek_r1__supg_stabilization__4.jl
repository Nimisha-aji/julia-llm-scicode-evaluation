function supg_tau(u::Real, kappa::Real, h::Real)::Float64
    u_abs = abs(float(u))
    kappa_f = float(kappa)
    h_f = float(h)
    if u_abs == 0.0
        return h_f^2 / (12.0 * kappa_f)
    end
    Pe = u_abs * h_f / (2.0 * kappa_f)
    if Pe < 1e-12
        return h_f^2 / (12.0 * kappa_f)
    else
        return (h_f / (2.0 * u_abs)) * (coth(Pe) - 1.0 / Pe)
    end
end