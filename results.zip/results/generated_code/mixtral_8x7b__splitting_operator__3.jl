function strang_splitting(u0::Array{T,1}, dt::T, nt::Int64, L1::Function, L2::Function) where T<:Real
    u = zeros(nt, length(u0))
    for i in 1:nt
        u[i] = L1(u0[1], dt) + L2(u0[2:end