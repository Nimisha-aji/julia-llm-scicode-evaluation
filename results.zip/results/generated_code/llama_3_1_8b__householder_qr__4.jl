function householder_qr(A)
    m, n = size(A)
    Q = I(m)
    R = copy(A)

    for j in 1:min(m, n)
        v = R[j:m, j]
        v = v .- sign(v[1]) * norm(v)
        α = 2 / v'v
        v = α * v
        v[1] += 1
        Q[:, j:m] .-= 2 * v * v'
        R[j:m, j:m] .-= 2 * v * v'
    end

    return Q, R
end