function burgers_solver(nu, nx, nt, dx, dt)
    # spatial grid
    x = range(0, step=dx, length=nx)
    # initial condition (periodic)
    u = @. sin(2π * x)
    # temporary array
    u_new = similar(u)
    for n in 1:nt
        for i in 1:nx
            # periodic indices
            ip = i == nx ? 1 : i + 1
            im = i == 1 ? nx : i - 1
            # convection term using upwind
            if u[i] > 0
                du_dx = (u[i] - u[im]) / dx
            else
                du_dx = (u[ip] - u[i]) / dx
            end
            # diffusion term (central)
            d2u_dx2 = (u[ip] - 2u[i] + u[im]) / dx^2
            # explicit update
            u_new[i] = u[i] - dt * u[i] * du_dx + nu * dt * d2u_dx2
        end
        # update solution
        u, u_new = u_new, u
    end
    return u
end