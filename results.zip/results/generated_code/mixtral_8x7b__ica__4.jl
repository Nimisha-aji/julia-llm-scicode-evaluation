using Random
using LinearAlgebra
using Statistics
using Plots

function ica_demix(X::Matrix{<:Real}, n_components::Int64, max_iter::Int64, tol::Float64)
    Random.seed!(42)

    # Calculate mean of X
    μ = mean(X, dims=1)

    # Subtract mean from X
    X_mean_subtracted = X .- μ

    # Calculate covariance matrix of X_mean_subtracted
    C = cov(X_mean_subtracted)

    # Calculate eigenvalues and eigenvectors of C
    λ, v = eig(C)

    # Sort eigenvalues in descending order
    λ = λ[sortperm(λ)[1:n_components+1], :]

    # Calculate normalized eigenvectors
    v = v ./ sqrt(sum(λ, dims=2))

    # Calculate demixing matrix W
    W = v[:, 1:n_components]

    # Perform FastICA algorithm
    for iter in 1:max_iter
        # Calculate mixing matrix A
        A = X_mean_subtracted .* W

        # Calculate independent components
        Y = A .* W

        # Calculate covariance matrix of Y
        C_Y = cov(Y)

        # Calculate new eigenvectors
        v_new = eigvals!(C_Y, v)

        # Update demixing matrix W
        W = v_new[:, 1:n_components]

        # Calculate mixing matrix A
        A = X_mean_subtracted .* W

        # Calculate independent components
        Y = A .* W

        # Check convergence
        if norm(Y - Y_prev) < tol
            break
        end

        # Update Y_prev
        Y_prev = Y
    end

    return W
end