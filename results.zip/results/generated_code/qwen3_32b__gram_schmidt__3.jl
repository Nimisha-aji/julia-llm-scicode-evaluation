function gram_schmidt(A)
    n, m = size(A)
    Q = zeros(eltype(A), n, m)
    for j in 1:m
        v = copy(A[:,j])
        for i in 1:(j-1)
            v -= dot(Q[:,i], v) * Q[:,i]
        end
        Q[:,j] = v / norm(v)
    end
    return Q
end