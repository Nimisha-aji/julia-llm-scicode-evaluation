function supg_tau(u, kappa, h)
    Pe = u * h / (2 * kappa)
    if Pe <= 1
        return h / (2 * u) * (1 - (1 / Pe) * (1 - exp(-Pe)))
    else
        return h / (2 * u)
    end
end