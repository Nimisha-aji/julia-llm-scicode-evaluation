function incomplete_cholesky(A)
    n = size(A, 1)
    L = zeros(n, n)
    
    for i in 1:n
        for j in (i+1):n
            if A[i,j] > 0.0
                L[i,j] = sqrt(A[i,j])
            else
                L[i,j] = 0.0
            end