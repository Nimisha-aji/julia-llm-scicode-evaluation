function gram_schmidt(A)
    n = size(A, 2)
    Q = similar(A)
    for i in 1:n
        v = A[:,i]
        for j in 1:i-1
            v -= dot(Q[:,j], A[:,i]) * Q[:,j]
        end
        Q[:,i] = v / norm(v)
    end
    return Q
end