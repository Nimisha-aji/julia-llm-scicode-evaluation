function nurbs_basis(i::Int, p::Int, t::Float64, knots::Vector{Float64})::Float64
    if p == 0
        if knots[i] <= t < knots[i+1]
            return 1.0
        else
            return 0.0
        end
    else
        d1 = knots[i+p] - knots[i]
        d2 = knots[i+p+1] - knots[i+1]
        e1 = (t - knots[i]) / d1
        e2 = (knots[i+p+1] - t) / d2
        if d1 == 0
            e1 = 0.0
        else
            e1 = (t - knots[i]) / d1
        end
        if d2 == 0
            e2 = 0.0
        else
            e2 = (knots[i+p+1] - t) / d2
        end
        return e1 * nurbs_basis(i, p-1, t, knots) + e2 * nurbs_basis(i+1, p-1, t, knots)
    end
end