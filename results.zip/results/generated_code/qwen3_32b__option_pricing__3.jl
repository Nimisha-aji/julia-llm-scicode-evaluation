function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    Z = randn(n_paths, n_steps)
    sum_Z = dropdims(sum(Z, dims=2), dims=2)
    drift_term = (r - 0.5*sigma^2) * T
    sigma_term = sigma * sqrt(dt) * sum_Z
    S_T = S0 * exp.(drift_term .+ sigma_term)
    payoff = max.(S_T .- K, 0)
    discount = exp(-r*T)
    price = discount * mean(payoff)
    return price
end