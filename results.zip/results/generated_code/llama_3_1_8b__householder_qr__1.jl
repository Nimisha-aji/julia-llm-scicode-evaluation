function householder_qr(A)
    m, n = size(A)
    Q = I(m)
    R = copy(A)

    for j = 1:min(m, n)
        v = R[j:m, j]
        v = v - sign(v[1]) * norm(v) * ones(m - j + 1)
        v = v / norm(v)
        R[j:m, j:m] -= 2 * v * v'
        Q[:, j:m] -= 2 * v * v' * Q[:, j:m]
    end

    return Q, R
end