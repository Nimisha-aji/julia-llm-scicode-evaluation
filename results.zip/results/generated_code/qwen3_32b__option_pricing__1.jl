function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    drift = (r - 0.5 * sigma^2) * dt
    vol = sigma * sqrt(dt)
    payoffs = zeros(n_paths)
    for i in 1:n_paths
        S = S0
        for j in 1:n_steps
            S *= exp(drift + vol * randn())
        end
        payoffs[i] = max(S - K, 0)
    end
    return exp(-r * T) * mean(payoffs)
end