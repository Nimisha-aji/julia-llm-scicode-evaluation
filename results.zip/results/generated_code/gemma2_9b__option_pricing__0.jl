using Random, Distributions

function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    S = zeros(n_paths, n_steps + 1)
    S[:, 1] .= S0
    
    for i in 1:n_paths
        for t in 2:(n_steps + 1)
            z = randn()
            S[i, t] = S[i, t-1] * exp((r - 0.5 * sigma^2) * dt + sigma * sqrt(dt) * z)
        end
    end
    
    payoff = exp(-r * T) * max.(S[:, end] - K, 0)
    price = mean(payoff)
    return price
end