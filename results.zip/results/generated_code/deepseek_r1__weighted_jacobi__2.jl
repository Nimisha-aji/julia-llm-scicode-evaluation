function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    D = diagm(0 => diag(A))
    D_inv = Diagonal(1 ./ diag(A))
    x = copy(x0)
    for k in 1:max_iter
        r = b - A * x
        if norm(r) < tol
            break
        end
        x .= x .+ omega .* (D_inv * r)
    end
    return x
end