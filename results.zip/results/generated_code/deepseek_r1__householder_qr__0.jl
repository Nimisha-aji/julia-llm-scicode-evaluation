function householder_qr(A)
    m, n = size(A)
    R = copy(A)
    Q = Matrix{eltype(A)}(I, m, m)

    for k in 1:min(m-1, n)
        x = R[k:end, k]
        σ = norm(x)
        if σ == 0
            continue
        end
        # Compute Householder vector v
        α = -sign(real(x[1])) * σ
        v = copy(x)
        v[1] -= α
        v /= norm(v)

        # Apply reflector to R
        R[k:end, k:end] .-= 2 .* (v * (v' * R[k:end, k:end]))

        # Accumulate reflector into Q
        Q[:, k:end] .-= 2 .* (Q[:, k:end] * (v * v'))
    end

    return Q, R
end