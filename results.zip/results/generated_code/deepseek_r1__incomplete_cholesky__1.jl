using SparseArrays

function incomplete_cholesky(A::SparseMatrixCSC{T}) where T<:Real
    n = size(A, 1)
    @assert n == size(A, 2) "Matrix must be square"
    L = spzeros(T, n, n)

    # Precompute column pointers for fast access
    colptr = A.colptr
    rowval = A.rowval
    nzval  = A.nzval

    for j in 1:n
        # Diagonal element
        diag_sum = zero(T)
        for p in L.colptr[j]:(L.colptr[j+1]-1)
            i = L.rowval[p]
            if i < j
                diag_sum += L.nzval[p]^2
            else
                break
            end
        end
        L[j, j] = sqrt(A[j, j] - diag_sum)

        # Off‑diagonal entries in column j (i > j)
        for pA in colptr[j]:(colptr[j+1]-1)
            i = rowval[pA]
            if i > j
                # compute sum_{k<j} L[i,k] * L[j,k]
                sum_ik_jk = zero(T)
                pL_i = L.colptr[j]   # start of column j in L (same as j)
                pL_j = L.colptr[j]   # start of column j in L
                while pL_i < L.colptr[j+1] && pL_j < L.colptr[j+1]
                    row_i = L.rowval[pL_i]
                    row_j = L.rowval[pL_j]
                    if row_i == row_j && row_i < j
                        sum_ik_jk += L.nzval[pL_i] * L.nzval[pL_j]
                        pL_i += 1
                        pL_j += 1
                    elseif row_i < row_j
                        pL_i += 1
                    else
                        pL_j += 1
                    end
                end
                L[i, j] = (A[i, j] - sum_ik_jk) / L[j, j]
            end
        end
    end
    return L
end