function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    
    # Calculate the number of time steps
    n_time_steps = Int(ceil(T / (1.0 / r)))
    
    # Calculate the number of paths
    n_paths = max(1, n_paths)
    
    # Calculate the number of steps per path
    n_steps_per_path = min(n_steps, n_paths)
    
    # Calculate the total number of paths
    n_total_paths = n_paths * n_steps_per_path
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per path
    n_time_steps_per_path = n_time_steps
    
    # Calculate the number of time steps per