function gauss_seidel(A, b, x0, tol, max_iter)
    n = size(A, 1)
    x = copy(x0)
    for iter in 1:max_iter
        for i in 1:n
            s = 0
            for j in 1:i-1
                s += A[i, j] * x[j]
            end
            for j in i+1:n
                s += A[i, j] * x[j]
            end
            x[i] = (b[i] - s) / A[i, i]
        end
        if norm(x - x0) < tol
            return x
        end
        x0 = copy(x)
    end
    return x
end