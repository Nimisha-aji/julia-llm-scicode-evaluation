function burgers_solver(nu, nx, nt, dx, dt)
    # Initialize solution vector
    u = zeros(nx)

    # Set initial condition
    for i in 1:nx
        x = (i - 1) * dx
        u[i] = 1 - sin(2 * π * x)
    end

    # Time-stepping
    for _ in 1:nt
        u_new = zeros(nx)
        for i in 2:nx
            u_new[i] = u[i] - dt / dx * u[i] * (u[i] - u[i-1]) + nu * dt / dx^2 * (u[i+1] - 2u[i] + u[i-1])
        end
        u_new[1] = u[1] - dt / dx * u[1] * (u[1] - 0) + nu * dt / dx^2 * (u[2] - 2u[1] + 0)
        u_new[nx] = u[nx] - dt / dx * u[nx] * (u[nx] - u[nx-1]) + nu * dt / dx^2 * (0 - 2u[nx] + u[nx-1])
        u .= u_new
    end

    return u
end