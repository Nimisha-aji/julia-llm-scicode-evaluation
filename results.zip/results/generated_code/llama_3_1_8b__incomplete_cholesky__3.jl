function incomplete_cholesky(A, k = 1)
    n = size(A, 1)
    L = zeros(n, n)
    idx = 1
    for j in 1:n
        for i in idx:j
            s = 0
            for p in idx:i-1
                s += L[i, p] * L[j, p]
            end
            L[i, j] = (A[i, j] - s) / L[j, j]
            if i <= k
                L[j, i] = L[i, j]
            end
        end
        if L[j, j] <= 0
            error("Matrix is not positive definite")
        end
        idx = j + 1
    end
    return L
end