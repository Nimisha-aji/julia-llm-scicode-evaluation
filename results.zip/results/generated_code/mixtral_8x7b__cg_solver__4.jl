function cg_solver(A, b, x0, tol)
    n = size(A, 1) # get number of rows of matrix A
    x = zeros(n) # initialize solution vector x

    # Conjugate Gradient iterations
    for i in 1:100 # adjust number of iterations as needed
        r = b - A * x # compute residual vector r
        p = r / norm(r) # compute initial search direction p
        x -= p * dot(A, p) / dot(A, r) # update solution vector x
        r -= p * dot(A, r) / dot(A, p) # update residual vector r
        if norm(r) < tol # stop if residual is below tolerance
            return x
        end
    end

    return x # return solution vector x if no convergence
end