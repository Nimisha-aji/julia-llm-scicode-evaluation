```julia
using Random

function black_scholes_mc(S0::Float64, K::Float64, r::Float64, sigma::Float64, T::Float64, n_paths::Int64, n_steps::Int64)
    Random.seed!(42)

    # Calculate the strike price
    strike = K * sqrt(T)

    # Calculate the Black-Scholes parameters
    σ = sigma * sqrt(T)
    rho = sigma * σ
    r_σ = r / σ

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the number of paths and steps
    num_paths = n_path