using LinearAlgebra

function gram_schmidt(A)
    m, n = size(A)
    Q = zeros(m, n)
    for j = 1:n
        v = A[:, j]
        for i = 1:j-1
            Q[:, i] = Q[:, i] / norm(Q[:, i])
            v = v - dot(Q[:, i], v) * Q[:, i]
        end
        Q[:, j] = v / norm(v)
    end
    return Q
end