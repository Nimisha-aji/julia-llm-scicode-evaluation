using FastICA
using Random

function ica_demix(X, n_components, max_iter, tol)
    Random.seed!(42)
    W = FastICA.ica(X, n_components; max_iter=max_iter, tol=tol)
    return W
end