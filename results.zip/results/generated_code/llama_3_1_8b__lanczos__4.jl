function lanczos(A, v0, k)
    alpha = zeros(k)
    beta = zeros(k)
    v = copy(v0)
    v = v / norm(v)
    alpha[1] = dot(v, A * v)
    beta[1] = norm(A * v - alpha[1] * v)
    for i in 2:k
        w = A * v - alpha[i-1] * v - beta[i-1] * v
        w = w / beta[i-1]
        alpha[i] = dot(w, A * w)
        beta[i] = norm(A * w - alpha[i] * w)
        v = w
        v = v / norm(v)
    end
    return alpha, beta
end