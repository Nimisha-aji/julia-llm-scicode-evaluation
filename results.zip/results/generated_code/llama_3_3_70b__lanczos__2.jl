function lanczos(A, v0, k)
    n = size(A, 1)
    Q = zeros(n, k+1)
    alpha = zeros(k)
    beta = zeros(k+1)
    Q[:, 1] = v0 / norm(v0)
    q = Q[:, 1]
    beta[1] = 0
    for i = 1:k
        w = A * q
        alpha[i] = q' * w
        w = w - alpha[i] * q
        if i > 1
            w = w - beta[i] * Q[:, i-1]
        end
        beta[i+1] = norm(w)
        if beta[i+1] > 0
            Q[:, i+1] = w / beta[i+1]
        end
        q = Q[:, i+1]
    end
    return alpha, beta[2:end]
end