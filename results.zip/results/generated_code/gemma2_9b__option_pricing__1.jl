using Random, Distributions

function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    ST = zeros(n_paths)
    
    for i in 1:n_paths
        S = S0
        for _ in 1:n_steps
            z = randn()
            S *= exp((r - 0.5 * sigma^2) * dt + sigma * sqrt(dt) * z)
        end
        ST[i] = S
    end
    
    payoff = max.(ST .- K, 0)
    price = exp(-r * T) * mean(payoff)
    return price
end