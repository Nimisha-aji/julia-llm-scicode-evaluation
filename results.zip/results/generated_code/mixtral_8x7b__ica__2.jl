using Random
using Statistics
using LinearAlgebra
using IterativeSolvers
using Plots

function ica_demix(X::Matrix{<:Number}, n_components::Int64, max_iter::Int64, tol::Float64)
    Random.seed!(42)

    # Check input dimensions
    if size(X, 2) != size(X, 1)
        error("Input matrix X should have the same number of rows and columns.")
    end

    # Calculate mean of X
    mean_X = mean(X, dims=1)

    # Subtract mean from X
    X_mean_subtracted = X .- mean_X

    # Calculate covariance matrix of X_mean_subtracted
    cov_X = cov(X_mean_subtracted)

    # Calculate eigenvalues and eigenvectors of covariance matrix
    evals, evecs = eig(cov_X)

    # Sort eigenvectors by eigenvalues
    evecs_sorted = evecs[:, sortperm(evals)]

    # Calculate mixing matrix A
    A = evecs_sorted[:, 1:n_components]

    # Calculate initial demixing matrix W
    W = A'

    # Iterative algorithm for demixing
    for iter in 1:max_iter
        # Calculate demixing matrix W_new
        W_new = A * W

        # Calculate mixing matrix A_new
        A_new = W_new'

        # Calculate residual matrix R
        R = X * W

        # Calculate demixing matrix W_new using FastICA algorithm
        W_new = fastICA(R, A, A_new, tol=tol)

        # Update W and A
        W = W_new
        A = A_new

        # Check convergence
        if norm(R) < tol
            break
        end
    end

    # Return demixing matrix W
    return W
end