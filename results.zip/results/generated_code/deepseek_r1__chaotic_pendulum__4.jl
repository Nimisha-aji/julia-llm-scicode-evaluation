function pendulum_rk4(theta0, omega0, dt, nt, g, L, b)
    θ = similar(zeros(nt+1))
    θ[1] = theta0
    ω = omega0
    for i in 1:nt
        # Define derivatives
        fθ(ω) = ω
        fω(θ, ω) = -(g/L)*sin(θ) - b*ω

        # k1
        k1θ = dt * fθ(ω)
        k1ω = dt * fω(θ[i], ω)

        # k2
        k2θ = dt * fθ(ω + 0.5*k1ω)
        k2ω = dt * fω(θ[i] + 0.5*k1θ, ω + 0.5*k1ω)

        # k3
        k3θ = dt * fθ(ω + 0.5*k2ω)
        k3ω = dt * fω(θ[i] + 0.5*k2θ, ω + 0.5*k2ω)

        # k4
        k4θ = dt * fθ(ω + k3ω)
        k4ω = dt * fω(θ[i] + k3θ, ω + k3ω)

        # Update
        θ[i+1] = θ[i] + (k1θ + 2k2θ + 2k3θ + k4θ) / 6
        ω = ω + (k1ω + 2k2ω + 2k3ω + k4ω) / 6
    end
    return θ
end