function gram_schmidt(A::Matrix{<:Real})
    n, m = size(A)
    Q = zeros(m, m)

    for i in 1:m
        u = A[:, i]
        Q[i, :] = u / norm(u)

        for j in (i+1):m
            v = A[:, j]
            Q[j, :] = v / norm(v)
            Q[j, i] = dot(Q[i, :], v)
        end