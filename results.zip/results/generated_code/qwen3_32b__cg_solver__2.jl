function cg_solver(A, b, x0, tol)
    x = copy(x0)
    r = b - A * x
    rs_old = r' * r
    p = r
    tol2 = tol^2
    while rs_old > tol2
        Ap = A * p
        alpha = rs_old / (p' * Ap)
        x = x + alpha * p
        r = r - alpha * Ap
        rs_new = r' * r
        beta = rs_new / rs_old
        p = r + beta * p
        rs_old = rs_new
    end
    return x
end