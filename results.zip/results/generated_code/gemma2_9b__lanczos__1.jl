function lanczos(A, v0, k)
    n = length(v0)
    alpha = zeros(k)
    beta = zeros(k)
    v = [v0 / norm(v0)]
    for i in 1:k
        w = A * v[end]
        alpha[i] = dot(v[end], w)
        w -= alpha[i] * v[end]
        if i > 1
            w -= beta[i-1] * v[end-1]
        end
        beta[i] = norm(w)
        push!(v, w / beta[i])
    end
    return (alpha, beta)
end