function supg_tau(u, kappa, h)
    Pe = abs.(u) .* h ./ (2 .* kappa)
    tau = h ./ (abs.(u) .* sqrt.(ones(size(u)) .+ (h ./ (2 .* kappa) .* abs.(u)).^2))
    return tau
end