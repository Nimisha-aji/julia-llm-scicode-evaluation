function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    n = length(b)
    x = copy(x0)
    for _ in 1:max_iter
        x_new = copy(x)
        for i in 1:n
            s = 0
            for j in 1:n
                if j != i
                    s += A[i, j] * x[j]
                end
            end
            x_new[i] = (1 - omega) * x[i] + omega * (b[i] - s) / A[i, i]
        end
        if norm(x - x_new) < tol
            return x_new
        end
        x = x_new
    end
    return x
end