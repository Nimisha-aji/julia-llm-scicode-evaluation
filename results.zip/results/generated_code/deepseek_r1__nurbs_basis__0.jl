function nurbs_basis(i::Int, p::Int, t::Float64, knots::AbstractVector{<:Real})::Float64
    if p == 0
        return (knots[i] ≤ t < knots[i+1]) ? 1.0 : 0.0
    else
        denom1 = knots[i+p] - knots[i]
        term1 = denom1 == 0 ? 0.0 : ((t - knots[i]) / denom1) * nurbs_basis(i, p-1, t, knots)

        denom2 = knots[i+p+1] - knots[i+1]
        term2 = denom2 == 0 ? 0.0 : ((knots[i+p+1] - t) / denom2) * nurbs_basis(i+1, p-1, t, knots)

        return term1 + term2
    end
end