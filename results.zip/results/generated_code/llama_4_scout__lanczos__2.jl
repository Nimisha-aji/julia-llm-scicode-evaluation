function lanczos(A, v0, k)
    n = length(v0)
    v = [similar(v0) for _ in 1:k]
    v[1] = v0 ./ norm(v0)
    alpha = zeros(k)
    beta = zeros(k-1)

    w = A * v[1]
    alpha[1] = dot(v[1], w)
    w -= alpha[1] * v[1]

    for i in 2:k
        beta[i-1] = norm(w)
        if beta[i-1] < 1e-12
            break
        end
        v[i] = w ./ beta[i-1]
        w = A * v[i]
        alpha[i] = dot(v[i], w)
        w -= beta[i-1] * v[i-1] + alpha[i] * v[i]
    end

    return (alpha[1:k], beta[1:k-1])
end