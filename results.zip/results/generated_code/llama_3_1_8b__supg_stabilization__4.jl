function supg_tau(u, kappa, h)
    c = maximum(abs.(u))
    return (c*h)/(2*kappa)
end