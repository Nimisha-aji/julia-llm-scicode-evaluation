function gauss_seidel(A::AbstractMatrix, b::AbstractVector, x0::AbstractVector, tol::Real, max_iter::Integer)
    n = length(b)
    x = copy(x0)
    for k in 1:max_iter
        x_old = copy(x)
        for i in 1:n
            sigma = zero(eltype(A))
            for j in 1:i-1
                sigma += A[i, j] * x[j]
            end
            for j in i+1:n
                sigma += A[i, j] * x_old[j]
            end
            x[i] = (b[i] - sigma) / A[i, i]
        end
        if norm(x - x_old, Inf) < tol
            return x
        end
    end
    return x
end