function burgers_solver(nu::Float64, nx::Int, nt::Int, dx::Float64, dt::Float64)
    # spatial grid (periodic domain [0,1])
    x = range(0, step=dx, length=nx)
    # initial condition: sine wave
    u = @. sin(2π * x)
    # preallocate temporary array
    u_new = similar(u)
    # coefficients for diffusion term
    coeff = nu * dt / dx^2
    for _ = 1:nt
        @inbounds for i = 1:nx
            im1 = i == 1 ? nx : i - 1   # i-1 with periodic wrap
            ip1 = i == nx ? 1 : i + 1   # i+1 with periodic wrap
            # upwind convection (backward difference)
            conv = u[i] * (u[i] - u[im1]) / dx
            # diffusion (central difference)
            diff = (u[ip1] - 2u[i] + u[im1])
            u_new[i] = u[i] - dt * conv + coeff * diff
        end
        u, u_new = u_new, u   # swap references for next step
    end
    return u
end