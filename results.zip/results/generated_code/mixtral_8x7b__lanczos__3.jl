function lanczos(A, v0, k)
    α, β = 0.0, 0.0
    v = v0

    for i in 1:k
        α, β = lanczos_step(A, v)
        v = v * α / β
    end