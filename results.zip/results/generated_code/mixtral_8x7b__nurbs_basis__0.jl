function nurbs_basis(i::Int, p::Int, t::Float64, knots::Vector{Float64})
    if i == 0
        return 1.0
    end