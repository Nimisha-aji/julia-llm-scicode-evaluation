function burgers_solver(nu, nx, nt, dx, dt)
    # Initialize solution vector
    u = zeros(nx)

    # Initial condition
    for i in 1:nx
        x = (i - 1) * dx
        u[i] = 1 - (x - 0.5)^2 + 0.25 * sin(3 * pi * x)
    end

    # Time-stepping
    for _ in 1:nt
        u_new = zeros(nx)
        for i in 2:nx
            u_new[i] = u[i] - dt / dx * u[i] * (u[i] - u[i-1]) + nu * dt / dx^2 * (u[i+1] - 2 * u[i] + u[i-1])
        end
        # Apply boundary conditions
        u_new[1] = u[1] - dt / dx * u[1] * (u[1] - u[1]) + nu * dt / dx^2 * (u[2] - 2 * u[1] + u[1])
        u_new[nx] = u[nx] - dt / dx * u[nx] * (u[nx] - u[nx-1]) + nu * dt / dx^2 * (u[nx] - 2 * u[nx] + u[nx-1])
        u = u_new
    end

    return u
end