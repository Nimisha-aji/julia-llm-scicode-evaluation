function incomplete_cholesky(A)
    n = size(A, 1)
    L = zeros(n, n)
    for j in 1:n
        # Compute diagonal entry
        s = A[j,j]
        for k in 1:j-1
            s -= L[j,k]^2
        end
        L[j,j] = sqrt(s)
        # Compute entries below diagonal in column j
        for i in j+1:n
            s = A[i,j]
            for k in 1:j-1
                s -= L[i,k] * L[j,k]
            end
            L[i,j] = s / L[j,j]
        end
        # Do not update the submatrix
    end
    return L
end