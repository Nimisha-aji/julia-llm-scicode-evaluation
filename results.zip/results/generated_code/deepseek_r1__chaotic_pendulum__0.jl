function pendulum_rk4(theta0, omega0, dt, nt, g, L, b)
    θ = zeros(nt+1)
    ω = zeros(nt+1)
    θ[1] = theta0
    ω[1] = omega0
    for i in 1:nt
        # k1
        k1θ = ω[i]
        k1ω = -(g/L)*sin(θ[i]) - b*ω[i]

        # k2
        θ2 = θ[i] + 0.5*dt*k1θ
        ω2 = ω[i] + 0.5*dt*k1ω
        k2θ = ω2
        k2ω = -(g/L)*sin(θ2) - b*ω2

        # k3
        θ3 = θ[i] + 0.5*dt*k2θ
        ω3 = ω[i] + 0.5*dt*k2ω
        k3θ = ω3
        k3ω = -(g/L)*sin(θ3) - b*ω3

        # k4
        θ4 = θ[i] + dt*k3θ
        ω4 = ω[i] + dt*k3ω
        k4θ = ω4
        k4ω = -(g/L)*sin(θ4) - b*ω4

        # update
        θ[i+1] = θ[i] + (dt/6)*(k1θ + 2k2θ + 2k3θ + k4θ)
        ω[i+1] = ω[i] + (dt/6)*(k1ω + 2k2ω + 2k3ω + k4ω)
    end
    return θ
end