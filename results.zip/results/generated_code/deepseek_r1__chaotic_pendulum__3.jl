function pendulum_rk4(theta0, omega0, dt, nt, g, L, b)
    θ = zeros(nt+1)
    ω = zeros(nt+1)
    θ[1] = theta0
    ω[1] = omega0
    for i in 1:nt
        # Define derivatives
        fθ(θ, ω) = ω
        fω(θ, ω) = -(g/L)*sin(θ) - b*ω

        k1θ = dt * fθ(θ[i], ω[i])
        k1ω = dt * fω(θ[i], ω[i])

        k2θ = dt * fθ(θ[i] + 0.5*k1θ, ω[i] + 0.5*k1ω)
        k2ω = dt * fω(θ[i] + 0.5*k1θ, ω[i] + 0.5*k1ω)

        k3θ = dt * fθ(θ[i] + 0.5*k2θ, ω[i] + 0.5*k2ω)
        k3ω = dt * fω(θ[i] + 0.5*k2θ, ω[i] + 0.5*k2ω)

        k4θ = dt * fθ(θ[i] + k3θ, ω[i] + k3ω)
        k4ω = dt * fω(θ[i] + k3θ, ω[i] + k3ω)

        θ[i+1] = θ[i] + (k1θ + 2k2θ + 2k3θ + k4θ) / 6
        ω[i+1] = ω[i] + (k1ω + 2k2ω + 2k3ω + k4ω) / 6
    end
    return θ
end