function supg_tau(u, kappa, h)
    Pe = abs(u) * h / (2 * kappa)
    if Pe <= 1
        return h / (2 * abs(u))
    else
        return kappa / abs(u)
    end
end