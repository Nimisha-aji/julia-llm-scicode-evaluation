function householder_qr(A)
    m, n = size(A)
    R = copy(A)
    Q = Matrix{Float64}(I, m, m)

    for j in 1:n
        x = view(R, j:m, j)
        σ = norm(x)
        if x[1] < 0
            σ = -σ
        end
        v = copy(x)
        v[1] = v[1] - σ
        β = 2 * v[1]^2 / (dot(v, v))
        R[j:m, j:n] .-= β * (v * v') * R[j:m, j:n]
        Q[:, j:m] .-= β * (Q[:, j:m] * v) * v'
    end

    return (Q, R)
end