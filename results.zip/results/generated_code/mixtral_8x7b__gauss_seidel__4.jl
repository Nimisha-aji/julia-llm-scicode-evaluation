function gauss_seidel(A, b, x0, tol, max_iter)
    n = size(A, 1)
    x = similar(x0)

    for iter in 1:max_iter
        for i in 1:n
            for j in i+1:n
                x[j] -= A[i, j] * x[i]
            end