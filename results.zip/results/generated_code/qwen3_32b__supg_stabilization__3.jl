function supg_tau(u, kappa, h)
    return h / (2 * sqrt(u^2 + (2kappa / h)^2))
end