function cg_solver(A, b, x0, tol)
    n = size(A, 1) # get number of rows in matrix A
    x = zeros(n) # initialize solution vector x

    # Conjugate Gradient iterations
    for i in 1:100 # adjust number of iterations as needed
        r = b - A * x # calculate residual vector r
        p = r / norm(r) # calculate initial search direction p
        x -= p * dot(A, p) / dot(A, r) # update solution vector x
        r -= dot(A, p) * p / dot(A, r) # update residual vector r
        if norm(r) <= tol * norm(b) # stop condition
            break
        end