function cg_solver(A, b, x0, tol)
    x = copy(x0)
    r = b - A * x
    p = copy(r)
    rsold = dot(r, r)
    tol2 = (tol * norm(b))^2
    maxiter = length(b)
    for i in 1:maxiter
        Ap = A * p
        α = rsold / dot(p, Ap)
        x .+= α .* p
        r .-= α .* Ap
        rsnew = dot(r, r)
        if rsnew < tol2
            break
        end
        p .= r .+ (rsnew / rsold) .* p
        rsold = rsnew
    end
    return x
end