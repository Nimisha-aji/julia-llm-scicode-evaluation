function nurbs_basis(i::Int, p::Int, t::Float64, knots::Vector{Float64})::Float64
    if p == 0
        return (t >= knots[i] && t < knots[i+1]) ? 1.0 : 0.0
    else
        term1 = 0.0
        term2 = 0.0
        if knots[i+p] != knots[i]
            term1 = (t - knots[i]) / (knots[i+p] - knots[i]) * nurbs_basis(i, p-1, t, knots)
        end
        if knots[i+p+1] != knots[i+1]
            term2 = (knots[i+p+1] - t) / (knots[i+p+1] - knots[i+1]) * nurbs_basis(i+1, p-1, t, knots)
        end
        return term1 + term2
    end
end