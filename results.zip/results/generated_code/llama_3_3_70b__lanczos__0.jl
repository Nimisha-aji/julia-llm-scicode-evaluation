function lanczos(A, v0, k)
    n = size(A, 1)
    Q = zeros(n, k+1)
    alpha = zeros(k)
    beta = zeros(k)
    Q[:, 1] = v0 / norm(v0)
    q = Q[:, 1]
    for i = 1:k
        r = A * q
        alpha[i] = q' * r
        r = r - alpha[i] * q
        if i > 1
            r = r - beta[i-1] * Q[:, i-1]
        end
        beta[i] = norm(r)
        if beta[i] > 0
            Q[:, i+1] = r / beta[i]
        else
            break
        end
        q = Q[:, i+1]
    end
    return alpha, beta
end