function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    Z = randn(n_paths, n_steps)
    S = fill(S0, n_paths)
    for i in 1:n_steps
        dW = Z[:,i] * sqrt(dt)
        S .= S .* (1 + r * dt) .+ S .* sigma .* dW
    end
    payoffs = max.(S .- K, 0)
    price = mean(payoffs) * exp(-r * T)
    return price
end