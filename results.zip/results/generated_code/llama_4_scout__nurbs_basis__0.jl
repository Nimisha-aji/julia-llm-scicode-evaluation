function nurbs_basis(i, p, t, knots)
    if p == 0
        if knots[i] <= t < knots[i + 1]
            return 1.0
        else
            return 0.0
        end
    else
        d1 = t - knots[i]
        d2 = knots[i + p + 1] - t
        N1 = (d1 == 0.0) ? 0.0 : (nurbs_basis(i, p - 1, t, knots) * d1 / (knots[i + p] - knots[i]))
        N2 = (d2 == 0.0) ? 0.0 : (nurbs_basis(i + 1, p - 1, t, knots) * d2 / (knots[i + p + 1] - knots[i + 1]))
        return N1 + N2
    end
end