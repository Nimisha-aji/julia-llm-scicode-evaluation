function gauss_seidel(A, b, x0, tol, max_iter)
    n = length(b)
    x = copy(x0)
    for _ in 1:max_iter
        x_new = similar(x)
        for i in 1:n
            σ = 0.0
            for j in 1:i-1
                σ += A[i,j] * x_new[j]
            end
            for j in i+1:n
                σ += A[i,j] * x[j]
            end
            x_new[i] = (b[i] - σ) / A[i,i]
        end
        if norm(x_new - x) < tol
            return x_new
        end
        x = x_new
    end
    return x
end