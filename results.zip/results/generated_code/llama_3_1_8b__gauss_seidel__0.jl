function gauss_seidel(A, b, x0, tol, max_iter)
    n = size(A, 1)
    x = copy(x0)
    for _ in 1:max_iter
        x_new = copy(x)
        for i in 1:n
            s = 0
            for j in 1:i-1
                s += A[i, j] * x_new[j]
            end
            for j in i+1:n
                s += A[i, j] * x[j]
            end
            x_new[i] = (b[i] - s) / A[i, i]
        end
        if norm(x_new - x) < tol
            return x_new
        end
        x = copy(x_new)
    end
    return x
end