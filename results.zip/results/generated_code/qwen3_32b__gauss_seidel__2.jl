function gauss_seidel(A, b, x0, tol, max_iter)
    n = length(b)
    x = copy(x0)
    for _ in 1:max_iter
        for i in 1:n
            sigma = 0.0
            for j in 1:i-1
                sigma += A[i,j] * x[j]
            end
            for j in i+1:n
                sigma += A[i,j] * x[j]
            end
            x[i] = (b[i] - sigma) / A[i,i]
        end
        if norm(b - A * x) < tol
            return x
        end
    end
    return x
end