using LinearAlgebra
using Random

function ica_demix(X, n_components, max_iter, tol)
    Random.seed!(42)
    n_samples, n_features = size(X)
    W = randn(n_components, n_features)
    W ./= sqrt.(sum(W.^2, dims=2))
    for _ in 1:max_iter
        old_W = copy(W)
        for i in 1:n_components
            w = W[i, :]
            wX = w' * X
            g = tanh.(3 * wX)
            g_prime = 1 .- 3 * wX.^2
            w_new = (X * g') / n_samples - (g_prime' * ones(n_samples)) / n_samples * w
            w_new ./= sqrt(sum(w_new.^2))
            W[i, :] = w_new
            # orthogonalization
            for j in 1:(i-1)
                W[i, :] -= W[j, :] * (W[j, :]' * W[i, :])
            end
            W[i, :] ./= sqrt(sum(W[i, :].^2))
        end
        if norm(W - old_W) < tol
            break
        end
    end
    return W
end