function lanczos(A::AbstractMatrix, v0::AbstractVector, k::Int)
    n = size(A, 1)
    @assert size(A, 2) == n "Matrix A must be square"
    @assert length(v0) == n "Initial vector length must match matrix size"
    @assert k ≥ 1 "Number of steps k must be at least 1"

    # Normalize initial vector
    q_prev = zeros(eltype(A), n)
    q = v0 / norm(v0)

    α = Vector{eltype(A)}(undef, k)
    β = Vector{eltype(A)}(undef, k)

    β[1] = zero(eltype(A))  # β₀ = 0 by convention

    for j in 1:k
        w = A * q
        α[j] = dot(q, w)
        w .-= α[j] .* q .+ β[j] .* q_prev
        β_next = norm(w)
        β[j+1] = β_next   # β_{j} stored at index j+1 (β₁ will be at β[2])
        if j == k
            # Trim β to length k (β₁…β_{k-1}); last β is not needed
            β = β[1:k]
            break
        end
        q_prev .= q
        q .= w / β_next
    end

    return (α, β[2:end])  # return β₁…β_{k-1}
end