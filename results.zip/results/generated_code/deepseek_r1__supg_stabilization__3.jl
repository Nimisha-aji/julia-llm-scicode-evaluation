function supg_tau(u::Real, kappa::Real, h::Real)::Float64
    u_abs = abs(u)
    if u_abs == 0.0
        return h^2 / (12.0 * kappa)
    end
    Pe = u_abs * h / (2.0 * kappa)
    if Pe < 1e-8
        # Use series expansion for small Pe: coth(Pe) ≈ 1/Pe + Pe/3
        return h^2 / (12.0 * kappa)
    else
        tau = (h / (2.0 * u_abs)) * (coth(Pe) - 1.0 / Pe)
        return Float64(tau)
    end
end