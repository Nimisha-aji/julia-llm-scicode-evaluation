function burgers_solver(nu, nx, nt, dx, dt)
    u = [sin(2π * (i-1) * dx) for i in 1:nx]  # initial condition
    for _ in 1:nt
        u_new = similar(u)
        for i in 1:nx
            im = i == 1 ? nx : i-1
            ip = i == nx ? 1 : i+1
            # Upwind convection term
            du_dx = u[i] >= 0 ? (u[i] - u[im]) / dx : (u[ip] - u[i]) / dx
            # Central diffusion term
            d2u_dx2 = (u[ip] - 2u[i] + u[im]) / dx^2
            u_new[i] = u[i] - dt * u[i] * du_dx + nu * dt * d2u_dx2
        end
        u = u_new
    end
    return u
end