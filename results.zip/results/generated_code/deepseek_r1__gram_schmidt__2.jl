function gram_schmidt(A::AbstractMatrix)
    m, n = size(A)
    Q = similar(A, m, n)
    for j in 1:n
        v = A[:, j]
        for i in 1:j-1
            v -= (Q[:, i]' * A[:, j]) * Q[:, i]
        end
        normv = norm(v)
        if normv ≈ 0
            Q[:, j] .= 0
        else
            Q[:, j] = v / normv
        end
    end
    return Q
end