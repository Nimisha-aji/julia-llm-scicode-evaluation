function strang_splitting(u0::Array, dt::Real, nt::Integer, L1::Function, L2::Function, L3::Function)
    u = similar(u0)
    for i in 1:nt
        u[i] = u0[i]
        for j in 1:(nt-1)
            u[j+1] = L1(u[j], dt)
        end