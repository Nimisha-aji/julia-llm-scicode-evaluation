using Random
using LinearAlgebra
using Statistics

function ica_demix(X::AbstractMatrix, n_components::Int, max_iter::Int, tol::Float64)
    Random.seed!(42)

    # Center the data (variables × observations)
    Xc = X .- mean(X, dims=2)

    # Whiten the data
    covX = cov(Xc; dims=2)
    evals, evecs = eigen(covX)
    D_inv_sqrt = Diagonal(1 ./ sqrt.(evals[1:n_components]))
    K = D_inv_sqrt * evecs[:, 1:n_components]'   # whitening matrix
    Z = K * Xc                                    # whitened data

    # Initialize demixing matrix
    W = randn(n_components, n_components)

    # Symmetric decorrelation function
    decorrelate!(M) = begin
        C = M * M'
        λ, E = eigen(C)
        M .= (E * Diagonal(1 ./ sqrt.(λ)) * E') * M
    end

    decorrelate!(W)

    N = size(Z, 2)

    for iter = 1:max_iter
        Y = W * Z
        G = tanh.(Y)
        Gp = 1 .- G .^ 2

        W_new = (G * Z') / N .- Diagonal(mean(Gp, dims=2)[:]) * W
        decorrelate!(W_new)

        if norm(abs.(W_new) - abs.(W), Inf) < tol
            W = W_new
            break
        end
        W = W_new
    end

    return W
end