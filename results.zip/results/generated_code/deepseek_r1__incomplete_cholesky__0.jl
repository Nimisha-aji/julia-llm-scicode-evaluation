using SparseArrays

function incomplete_cholesky(A::SparseMatrixCSC{T}) where T<:Real
    n = size(A, 1)
    @assert n == size(A, 2) "Matrix must be square"
    L = zeros(T, n, n)

    # Precompute column-wise nonzero indices for fast access
    colptr = A.colptr
    rowval = A.rowval
    nzval  = A.nzval

    for i in 1:n
        # Process columns j ≤ i where A[i,j] is nonzero
        for col in 1:i
            # locate A[i,col] in CSC storage
            start = colptr[col]
            stop  = colptr[col+1] - 1
            a_ij = zero(T)
            for idx in start:stop
                if rowval[idx] == i
                    a_ij = nzval[idx]
                    break
                end
            end
            if a_ij == zero(T) && i != col
                continue   # skip fill‑in entries (IC(0))
            end

            sum = a_ij
            for k in 1:col-1
                sum -= L[i,k] * L[col,k]
            end

            if i == col
                @assert sum > zero(T) "Non‑positive pivot encountered"
                L[i,i] = sqrt(sum)
            else
                L[i,col] = sum / L[col,col]
            end
        end
    end

    return sparse(L)
end