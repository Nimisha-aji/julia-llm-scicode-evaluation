function cg_solver(A, b, x0, tol)
    n = size(A, 1)
    r = b - A * x0
    p = r
    rsold = dot(r, r)
    x = x0
    iters = 0

    while true
        Ap = A * p
        alpha = rsold / dot(p, Ap)
        x = x + alpha * p
        r = r - alpha * Ap
        rsnew = dot(r, r)
        iters += 1

        if sqrt(rsnew) < tol
            break
        end

        p = r + (rsnew / rsold) * p
        rsold = rsnew
    end

    return x, iters
end