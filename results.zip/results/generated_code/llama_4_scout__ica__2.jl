using FastICA
using LinearAlgebra

function ica_demix(X, n_components, max_iter, tol)
    Random.seed!(42)
    W = FastICA.ica(X, n_components; max_iter=max_iter, tol=tol)
    return W
end

# Example usage:
X = randn(100, 10)  # Replace with your data
n_components = 3
max_iter = 1000
tol = 1e-4

W = ica_demix(X, n_components, max_iter, tol)
println(W)