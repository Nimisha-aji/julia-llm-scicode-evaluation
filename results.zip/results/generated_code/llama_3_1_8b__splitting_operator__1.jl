function strang_splitting(u0, dt, nt, L1, L2)
    u = copy(u0)
    for k in 1:nt
        u = L1(u, dt)
        u = L2(u, dt)
        u = L1(u, dt)
    end
    return u
end