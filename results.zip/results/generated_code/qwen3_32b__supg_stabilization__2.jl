function supg_tau(u, kappa, h)
    if u == 0
        return h^2 / (4kappa)
    else
        pe = u * h / (2kappa)
        return h / (2u) / sqrt(pe^2 + 1)
    end
end