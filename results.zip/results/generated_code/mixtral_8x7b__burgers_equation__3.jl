function burgers_solver(nu, nx, nt, dx, dt)
    u = zeros(nx)
    
    for t in 1:nt
        for i in 1:nx
            u[i] = (nu * u[i - 1] + 2 * u[i] - u[i + 1]) / dx^2 + dt * (u[i + 1] - 2 * u[i] + u[i - 1])
        end