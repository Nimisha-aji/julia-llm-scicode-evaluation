function burgers_solver(nu, nx, nt, dx, dt)
    u = zeros(nx)
    u[:] = 1.0

    for it in 1:nt
        for i in 2:nx
            if u[i-1] >= u[i]
                u[i] = u[i] - dt/dx * (u[i] - u[i-1])
            else
                u[i] = u[i] - dt/dx * (u[i-1] - u[i])
            end
        end
        u[1] = 1.0
    end

    return u
end