using LinearAlgebra

function cg_solver(A, b, x0, tol)
    x = copy(x0)
    r = b - A * x
    p = r
    while norm(r) > tol
        Ap = A * p
        α = dot(r, r) / dot(p, Ap)
        x .= x .+ α .* p
        r_new = r - α * Ap
        β = dot(r_new, r_new) / dot(r, r)
        p = r_new + β * p
        r = r_new
    end
    return x
end