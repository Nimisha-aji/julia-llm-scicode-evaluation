function ica_demix(X, n_components, max_iter, tol)
    # Center X
    X_centered = X - mean(X, dims=1)
    # Compute covariance matrix
    N = size(X, 1)
    C = (X_centered' * X_centered) / (N - 1)
    # Eigen decomposition
    U, Λ = eigen(C)
    # Whitening matrix
    D = size(X, 2)
    W_white = diagm(1 ./ sqrt.(diag(Λ))) * U'
    X_white = W_white * X_centered
    # Initialize demixing matrix W
    # For symmetric FastICA, W is D x D, but if we want n_components, perhaps we need to adjust
    # But perhaps the code is for the case where n_components = D
    # For now, assume n_components = D
    # Generate initial W as random orthogonal matrix
    Random.seed!(42)
    A = randn(D, D)
    Q, R = qr(A)
    W = Q
    # Now perform FastICA iterations
    for iter in 1:max_iter
        # For each component i
        for i in 1:D
            w = W[i, :]
            # Compute y = w' * X_white (each column is a sample)
            y = W[i, :] * X_white
            # Compute the nonlinearity: g(y) = tanh(y)
            g_y = tanh.(y)
            # g'(y) = 1 - tanh(y)^2
            g_prime_y = 1 .- g_y.^2
            # Compute w_new = (X_white * (g_prime_y'))' - mean(g_y) * w
            w_new = (X_white * (g_prime_y'))' - mean(g_y) * w
            # Normalize w_new
            w_new = w_new / norm(w_new)
            # Orthogonalize w_new with respect to other components
            for j in 1:D
                if j != i
                    w_new = w_new - (w_new' * W[j, :]) * W[j, :]
                end
            end
            # Normalize again
            w_new = w_new / norm(w_new)
            # Check convergence
            if norm(w_new - w) < tol
                break
            else
                W[i, :] = w_new
            end
        end
    end
    return W
end