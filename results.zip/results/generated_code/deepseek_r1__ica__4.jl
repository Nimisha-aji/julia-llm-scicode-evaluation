using LinearAlgebra, Random

function ica_demix(X::AbstractMatrix, n_components::Int, max_iter::Int, tol::Float64)
    Random.seed!(42)

    # Center the data
    Xc = X .- mean(X, dims=2)

    # Whitening
    covX = cov(Xc; dims=2)
    F = eigen(covX)
    D = Diagonal(F.values[1:n_components].^(-0.5))
    E = F.vectors[:, 1:n_components]
    Xw = D * (E' * Xc)

    # Initialize random demixing matrix
    W = randn(n_components, n_components)
    # Symmetric decorrelation
    W = W * inv(sqrt(W' * W))

    N = size(Xw, 2)

    for _ in 1:max_iter
        Y = W * Xw
        G = tanh.(Y)
        G_prime = 1 .- G.^2

        # Fixed‑point update (symmetric approach)
        W_new = (G * Xw') / N .- Diagonal(mean(G_prime, dims=2)[:]) * W

        # Symmetric decorrelation
        W_new = W_new * inv(sqrt(W_new' * W_new))

        # Convergence check
        lim = maximum(abs.(abs.(diag(W_new * W')) .- 1.0))
        W = W_new
        if lim < tol
            break
        end
    end

    return W
end