function lanczos(A, v0, k)
    n = size(A, 1)
    Q = zeros(n, k+1)
    Q[:, 1] = v0 / norm(v0)
    alpha = zeros(k)
    beta = zeros(k)
    q = Q[:, 1]
    for i = 1:k
        w = A * q
        alpha[i] = q' * w
        w = w - alpha[i] * q
        if i > 1
            w = w - beta[i-1] * Q[:, i-1]
        end
        beta[i] = norm(w)
        if beta[i] > 0
            Q[:, i+1] = w / beta[i]
        else
            break
        end
        q = Q[:, i+1]
    end
    return alpha, beta
end