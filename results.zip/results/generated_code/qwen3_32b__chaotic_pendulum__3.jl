function pendulum_rk4(theta0, omega0, dt, nt, g, L, b)
    theta = theta0
    omega = omega0
    angles = [theta]
    for _ in 1:nt
        k1θ = omega * dt
        k1ω = (- (b/L)*omega - (g/L)*sin(theta)) * dt
        
        k2θ = (omega + 0.5*k1ω) * dt
        k2ω = (- (b/L)*(omega + 0.5*k1ω) - (g/L)*sin(theta + 0.5*k1θ)) * dt
        
        k3θ = (omega + 0.5*k2ω) * dt
        k3ω = (- (b/L)*(omega + 0.5*k2ω) - (g/L)*sin(theta + 0.5*k2θ)) * dt
        
        k4θ = (omega + k3ω) * dt
        k4ω = (- (b/L)*(omega + k3ω) - (g/L)*sin(theta + k3θ)) * dt
        
        theta += (k1θ + 2*k2θ + 2*k3θ + k4θ)/6
        omega += (k1ω + 2*k2ω + 2*k3ω + k4ω)/6
        
        push!(angles, theta)
    end
    return angles
end