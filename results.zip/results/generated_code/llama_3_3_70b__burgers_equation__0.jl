function burgers_solver(nu, nx, nt, dx, dt)
    u = zeros(nx, nt)
    u[:, 1] = sin.(2 * pi * (0:nx-1) * dx)
    for n = 1:nt-1
        for i = 2:nx-1
            u[i, n+1] = u[i, n] - u[i, n] * dt / dx * (u[i, n] - u[i-1, n]) + nu * dt / dx^2 * (u[i+1, n] - 2 * u[i, n] + u[i-1, n])
        end
        u[1, n+1] = u[1, n] - u[1, n] * dt / dx * (u[1, n] - u[nx, n]) + nu * dt / dx^2 * (u[2, n] - 2 * u[1, n] + u[nx, n])
        u[nx, n+1] = u[nx, n] - u[nx, n] * dt / dx * (u[nx, n] - u[nx-1, n]) + nu * dt / dx^2 * (u[1, n] - 2 * u[nx, n] + u[nx-1, n])
    end
    return u[:, nt]
end