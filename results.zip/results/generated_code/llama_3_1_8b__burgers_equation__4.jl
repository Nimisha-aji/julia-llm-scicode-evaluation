function burgers_solver(nu, nx, nt, dx, dt)
    u = zeros(nx)
    u[:] = 1.0
    u[1] = 0.5
    u[nx] = 1.5

    for n in 1:nt
        for i in 2:nx
            if u[i-1] > u[i]
                u[i] = u[i] - nu * dt / dx * (u[i] - u[i-1])
            else
                u[i] = u[i] + nu * dt / dx * (u[i+1] - u[i])
            end
        end
    end

    return u
end