using Random

function ica_demix(X, n_components, max_iter, tol)
    Random.seed!(42)
    n, m = size(X)
    X = (X .- mean(X, dims=2)) ./ std(X, dims=2)
    W = randn(n_components, n_components)
    for iter in 1:max_iter
        W_new = similar(W)
        for i in 1:n_components
            wi = W[i, :]
            xw = X' * wi
            g = tanh.(xw)
            gprime = 1 .- tanh.(xw).^2
            W_new[i, :] = (X * g) / m - mean(g) * wi
        end
        W = W_new * W
        W = W ./ sqrt.(sum(W.^2, dims=2))
        if maximum(abs.(W - W_new)) < tol
            break
        end
    end
    return W
end