function gram_schmidt(A::Matrix{<:Number})
    n = size(A, 1)
    Q = zeros(n, n)

    for i in 1:n
        v = A[:, i]
        Q[i, :] = v / norm(v)

        for j in (i+1):n
            u = Q[:, j]
            Q[i, j:end