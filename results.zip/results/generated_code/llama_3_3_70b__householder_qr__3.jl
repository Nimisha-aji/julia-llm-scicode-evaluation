using LinearAlgebra

function householder_qr(A)
    m, n = size(A)
    Q = Matrix(I, m, m)
    R = copy(A)
    for j in 1:n
        x = view(R, j:m, j)
        v = householder_vector(x)
        H = householder_matrix(v)
        R[j:m, j:n] = H * R[j:m, j:n]
        Q = Q * H
    end
    return Q, R
end

function householder_vector(x)
    n = length(x)
    α = -sign(x[1]) * norm(x)
    e1 = zeros(n)
    e1[1] = 1
    v = x - α * e1
    v ./= norm(v)
    return v
end

function householder_matrix(v)
    n = length(v)
    H = Matrix(I, n, n) - 2 * v * v'
    return H
end

# Example usage:
A = [12 -51 4; 6 167 -68; -4 -41 -77]
Q, R = householder_qr(A)
println("Q:")
println(Q)
println("R:")
println(R)