function gram_schmidt(A)
    m, n = size(A)
    Q = zeros(m, n)
    for j = 1:n
        v = A[:, j]
        for i = 1:j-1
            v -= Q[:, i] * dot(Q[:, i], v)
        end
        norm_v = sqrt(dot(v, v))
        Q[:, j] = v / norm_v
    end
    return Q
end