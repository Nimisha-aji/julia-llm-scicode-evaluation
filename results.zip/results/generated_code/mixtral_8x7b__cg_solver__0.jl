function cg_solver(A::Array{T,2}, b::Array{T,1}, x0::Array{T,1}, tol::T) where T<:Number
    n, m = size(A)
    x = x0
    alpha = 1
    beta = 0
    
    while true
        p = A * x
        p ./= norm(p)
        
        y = b - p * x
        y ./= norm(y)
        
        x -= alpha * y
        alpha /= dot(p, y)
        
        beta = dot(p, y) / dot(p, p)
        
        if abs(beta) < tol
            break
        end
    end
    
    return x
end