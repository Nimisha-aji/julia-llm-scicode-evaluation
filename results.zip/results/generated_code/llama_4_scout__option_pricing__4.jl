using Random
using Distributions

function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    z = randn(n_paths, n_steps)
    S = zeros(n_paths, n_steps + 1)
    S[:, 1] .= S0
    for i in 1:n_steps
        S[:, i + 1] .= S[:, i] .* exp((r - 0.5 * sigma^2) * dt + sigma * sqrt(dt) .* z[:, i])
    end
    payoff = maximum(S[:, end] .- K, 0)
    discounted_payoff = payoff .* exp(-r * T)
    return mean(discounted_payoff)
end