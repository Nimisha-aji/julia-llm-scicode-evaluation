function burgers_solver(nu, nx, nt, dx, dt)
    u = rand(nx)  # Initial condition
    un = similar(u)

    for n in 1:nt
        un .= u
        for i in 2:nx
            flux = (un[i]^2 - un[i-1]^2) / 2
            u[i] = un[i] - dt/dx * flux + nu * dt/dx^2 * (un[i+1] - 2un[i] + un[i-1])
        end
    end

    return u
end