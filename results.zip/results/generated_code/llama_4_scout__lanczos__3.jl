function lanczos(A, v0, k)
    n = size(A, 1)
    @assert size(v0) == (n,)
    v0 = v0 / norm(v0)
    Q = zeros(n, k)
    Q[:, 1] = v0
    alpha = zeros(k)
    beta = zeros(k)

    v = A * v0
    alpha[1] = dot(v, v0)
    v = v - alpha[1] * v0

    for i in 2:k
        beta[i-1] = norm(v)
        if beta[i-1] ≈ 0
            break
        end
        Q[:, i] = v / beta[i-1]
        w = A * Q[:, i]
        alpha[i] = dot(w, Q[:, i])
        w = w - alpha[i] * Q[:, i] - beta[i-1] * Q[:, i-1]
        v = w
    end

    return (alpha[1:k], beta[1:k-1])
end