function black_scholes_mc(S0, K, r, sigma, T, n_paths, n_steps)
    Random.seed!(42)
    dt = T / n_steps
    dW = randn(n_paths, n_steps)
    St = zeros(n_paths)
    St[:] = S0
    for i in 1:n_steps
        St .= St .* exp.((r - 0.5 * sigma^2) * dt + sigma * sqrt(dt) * dW[:, i])
    end
    payoff = max.(St, 0) - K
    price = mean(payoff) * exp(-r * T)
    return price
end