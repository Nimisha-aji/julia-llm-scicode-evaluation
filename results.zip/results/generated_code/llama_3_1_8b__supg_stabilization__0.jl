function supg_tau(u, kappa, h)
    return 0.25 * (u * h / kappa)^2 / (1 + 0.25 * (u * h / kappa)^2)
end