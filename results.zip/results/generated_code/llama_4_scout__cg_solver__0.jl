function cg_solver(A, b, x0, tol)
    n = length(b)
    x = copy(x0)
    r = b - A * x
    p = copy(r)
    rsold = dot(r, r)

    for _ in 1:n
        Ap = A * p
        alpha = rsold / dot(p, Ap)
        x += alpha * p
        r -= alpha * Ap
        rsnew = dot(r, r)
        if sqrt(rsnew) < tol
            return x
        end
        p = r + (rsnew / rsold) * p
        rsold = rsnew
    end

    return x
end