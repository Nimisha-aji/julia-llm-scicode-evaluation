function lanczos(A, v0, k)
    n = size(A, 1)
    v = copy(v0)
    v = v ./ norm(v)
    alpha = zeros(k)
    beta = zeros(k)
    for i in 1:k
        alpha[i] = dot(v, A * v)
        w = A * v - alpha[i] * v
        beta[i] = norm(w)
        if beta[i] > 0
            w = w ./ beta[i]
            v = w
        end
    end
    return alpha[1:k], beta[1:k]
end