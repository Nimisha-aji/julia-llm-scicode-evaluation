using Random
using Statistics
using LinearAlgebra
using IterativeSolvers
using Plots

function ica_demix(X::Matrix{<:Real}, n_components::Int64, max_iter::Int64, tol::Float64)
    Random.seed!(42)

    # Check input dimensions
    if size(X, 2) != size(X, 1)
        error("Input matrix X must have the same number of rows and columns.")
    end

    # Calculate mean of X
    mean_X = mean(X, dims=1)

    # Subtract mean from X
    X_mean_subtracted = X .- mean_X

    # Calculate covariance matrix of X_mean_subtracted
    cov_X = cov(X_mean_subtracted)

    # Calculate eigenvalues and eigenvectors of covariance matrix
    eigenvalues, eigenvectors = eig(cov_X)

    # Sort eigenvectors by eigenvalues in descending order
    sorted_eigenvectors = eigenvectors[sortperm(eigvals = eigenvalues), :]

    # Normalize eigenvectors
    normalized_eigenvectors = sorted_eigenvectors ./ maximum(abs, sorted_eigenvectors)

    # Calculate demixing matrix W
    W = normalized_eigenvectors[:, 1:n_components]

    # Perform FastICA using normalized eigenvectors as initialization
    W_ICA = FastICA.ica(X_mean_subtracted, W, max_iter=max_iter, tol=tol)

    return W_ICA
end