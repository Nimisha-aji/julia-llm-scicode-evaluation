using Random

function black_scholes_mc(S0::Float64, K::Float64, r::Float64, sigma::Float64, T::Float64, n_paths::Int64, n_steps::Int64)
    Random.seed!(42)

    # Calculate the strike price
    strike = K * (1 + r)

    # Calculate the Black-Scholes parameters
    sigma_sqrt = sigma * sqrt(T)
    d1 = (log(S0 / strike) + (r + sigma_sqrt^2) * T) / (sigma_sqrt * T)
    d2 = d1 - sigma_sqrt

    # Calculate the number of paths and steps
    num_paths = n_paths
    num_steps = n_steps

    # Calculate the price using Monte Carlo simulation
    price = 0.0
    for i in 1:num_paths
        for j in 1:num_steps
            # Generate a random price path
            S = S0 * (1 + r * j) * randn()

            # Calculate the call option payoff
            payoff = max(0.0, strike - S)

            # Update the price
            price += payoff
        end
    end

    # Return the Monte Carlo estimated price
    return price / num_paths / num_steps
end