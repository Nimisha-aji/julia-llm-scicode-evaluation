function gauss_seidel(A, b, x0, tol, max_iter)
    n = length(b)
    x = copy(x0)
    iter = 0
    while iter < max_iter
        x_new = copy(x)
        for i in 1:n
            s = sum(A[i, j] * x_new[j] for j in 1:n if j != i)
            x_new[i] = (b[i] - s) / A[i, i]
        end
        if norm(x - x_new) < tol
            return x_new, iter + 1
        end
        x = x_new
        iter += 1
    end
    return x, iter
end

# Example usage:
A = [10  -1   2; 
     -1   11  -1; 
      2   -1   10]
b = [6; 25; -11]
x0 = zeros(3)
tol = 1e-6
max_iter = 100

x, iter = gauss_seidel(A, b, x0, tol, max_iter)
println("Solution: ", x)
println("Number of iterations: ", iter)