function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    n = size(A, 1)
    x = zeros(n)
    x[1] = x0[1]

    for iter in 1:max_iter
        for i in 1:n
            for j in (i + 1):n
                s = 0.0
                for k in (i + 1):n
                    s += A[i, k] * x[k]
                end