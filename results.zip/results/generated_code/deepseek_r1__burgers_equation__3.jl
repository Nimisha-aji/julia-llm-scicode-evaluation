function burgers_solver(nu::Float64, nx::Int, nt::Int, dx::Float64, dt::Float64)
    # spatial grid
    x = range(0, step=dx, length=nx)
    # initial condition (example: sine wave)
    u = @. sin(2π * x)

    # temporary array for updates
    u_new = similar(u)

    for _ = 1:nt
        # periodic boundary indices
        im1 = [nx; 1:nx-1]   # i-1
        ip1 = [2:nx; 1]      # i+1

        # convection term using upwind scheme
        conv = similar(u)
        for i in eachindex(u)
            if u[i] ≥ 0
                conv[i] = u[i] * (u[i] - u[im1[i]]) / dx
            else
                conv[i] = u[i] * (u[ip1[i]] - u[i]) / dx
            end
        end

        # diffusion term using central differences
        diff = @. (u[ip1] - 2u + u[im1]) / dx^2

        # explicit time stepping
        @. u_new = u - dt * conv + nu * dt * diff

        # update solution
        copyto!(u, u_new)
    end

    return u
end