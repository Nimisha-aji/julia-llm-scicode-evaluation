function incomplete_cholesky(A)
    n = size(A, 1)
    L = zeros(n, n)
    
    for i in 1:n
        for j in (i+1):n
            if A[i,j] != 0
                L[i,j] = sqrt(A[i,j])
                for k in (j+1):n
                    A[i,k] -= A[i,j] * L[i,j] * L[j,k]
                end