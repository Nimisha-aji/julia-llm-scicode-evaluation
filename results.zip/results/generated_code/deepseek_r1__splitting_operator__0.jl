function strang_splitting(u0, dt, nt, L1, L2)
    u = copy(u0)
    half_dt = dt/2
    for _ = 1:nt
        u = L1(u, half_dt)          # first half-step of L1
        u = L2(u, dt)               # full step of L2
        u = L1(u, half_dt)          # second half-step of L1
    end
    return u
end