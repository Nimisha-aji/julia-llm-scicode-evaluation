function weighted_jacobi(A::Array{T,2}, b::Array{T,1}, x0::Array{T,1}, omega::T, tol::T, max_iter::Int64) where {T<:Number}
    n, m = size(A)
    x = x0
    
    for iter in 1:max_iter
        for i in 1:n
            for j in i:n
                x[j] -= A[i,j] * (b[j] - sum(A[i,:]*x[1:j-1])) / omega
            end
        end
        
        if norm(x - x0) / norm(x0) <= tol
            break
        end
        x0 = x
    end
    
    return x
end