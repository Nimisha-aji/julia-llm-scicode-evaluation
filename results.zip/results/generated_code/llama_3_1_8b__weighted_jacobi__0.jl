function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    n = size(A, 1)
    D = diag(A)
    R = A - Diagonal(D)
    x = copy(x0)
    for _ in 1:max_iter
        x_new = similar(x)
        for i in 1:n
            s = 0
            for j in 1:n
                if j != i
                    s += R[i, j] * x[j]
                end
            end
            x_new[i] = (1 - omega) * x[i] + omega * (b[i] - s) / D[i]
        end
        if norm(x_new - x) < tol
            return x_new
        end
        x = x_new
    end
    return x
end