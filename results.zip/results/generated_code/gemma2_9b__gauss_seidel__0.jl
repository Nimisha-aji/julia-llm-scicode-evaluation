function gauss_seidel(A, b, x0, tol, max_iter)
    n = length(b)
    x = copy(x0)
    for iter in 1:max_iter
        x_new = copy(x)
        for i in 1:n
            sigma = 0.0
            for j in 1:n
                if j != i
                    sigma += A[i,j] * x_new[j]
                end
            end
            x_new[i] = (b[i] - sigma) / A[i,i]
        end
        if norm(x_new - x) < tol
            return x_new
        end
        x = x_new
    end
    return x
end