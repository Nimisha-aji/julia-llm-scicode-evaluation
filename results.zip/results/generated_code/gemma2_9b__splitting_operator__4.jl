function strang_splitting(u0, dt, nt, L1, L2)
    u = copy(u0)
    half_dt = dt / 2
    full_dt = dt

    for _ in 1:nt
        u = L2(u, half_dt)
        u = L1(u, dt)
        u = L2(u, half_dt)
    end

    return u
end