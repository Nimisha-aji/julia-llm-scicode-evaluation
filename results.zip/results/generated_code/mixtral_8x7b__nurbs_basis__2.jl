function nurbs_basis(i::Int, p::Int, t::Float64, knots::Vector{Float64})
    n = length(knots)
    if i < 1 || i > n
        return NaN
    end

    k = floor(Int, (i - 1) / p)
    m = floor(Int, (n - i) / p)

    basis = 0.0
    for j in 1:p
        for k in 1:p
            basis += knots[m + k - 1] * nurbs_basis(j, p, t, knots) * nurbs_basis(k, p, t, knots)
        end
    end

    for j in 1:p
        basis *= (1 - t)^(p - j)
    end

    basis *= t^k

    return basis
end