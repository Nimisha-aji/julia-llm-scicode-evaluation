function householder_qr(A)
    m, n = size(A)
    Q = Matrix(I, m, m)
    R = copy(A)
    for j in 1:min(m-1, n)
        x = view(R, j:m, j)
        e1 = zeros(eltype(x), length(x))
        e1[1] = 1
        v = x - norm(x) * e1
        v[1] += sign(x[1]) * norm(x)
        v = v / norm(v)
        H = I - 2 * v * v'
        Q = H * Q
        R[j:m, j:n] = H * view(R, j:m, j:n)
    end
    return Q, UpperTriangular(R)
end